
<?php
/**
 * Description: Default Index template to display loop of blog posts
 *
 * @package WordPress
 * @subpackage BootstrapWP
 */
get_header(); ?>

<?php
/**
 * 
$to = "neerajggverma@gmail.com";
$subject = "Apple Computer";
$message = "Steve, I think this computer thing might really take off.";

wp_mail( $to, $subject, $message );


*/
?>

<?php
 
// Some sample styles for the images
echo "<style type='text/css'>
	
	div#left-column {
	width: 333px;
	float: left;
	clear: none;
	}
div#right-column {
	width: 333px;
	float: right;
	clear: none;
	}
</style>\n";

?>


<div class="main home-page">
  <div class="home-inner">
  
  
	
  
    <!-- ROW 0 -->
    <div class="row row-0">
	
	

      <div class="container">
        <div class="h1">All you need in Forex</div>
        <div class="ads-group header-ads">

      </div>
    </div>
    
	
    <!-- ROW 1 -->
    <div class="row">
      <div class="home-col-830 main-box fr col-xs-12 col-sm-8">
        <!-- Main Story -->
        
  <div class="news-group main-story">
  
  
  
    <h2 class="main-story-title mobile"><a href="news/breaking-illegal-ireland-tax-benefits-to-apple-of-e13-billion/index.html">Breaking: €13 billion Apple Ireland Tax avoiding</a></h2>
        <a href="news/breaking-illegal-ireland-tax-benefits-to-apple-of-e13-billion/index.html" class="main-image" style="background-image: url('wp-content/uploads/2016/08/Illegal-Ireland-tax-benefits-to-Apple-of-%e2%82%ac13-billion-1.jpg');">
      <div class="news-content-tag mobile">
        BREAKING NEWS
      </div>
    </a>
    <div class="news-content">
      <h2 class="main-story-title"><a href="news/breaking-illegal-ireland-tax-benefits-to-apple-of-e13-billion/index.html">Breaking: €13 billion Apple Ireland Tax avoiding</a></h2>
      <p>
        The statement continued  that the Commission’s Apple Ireland tax avoiding case was not about how much Apple pays in taxes, but rather to which gover...        <a href="news/breaking-illegal-ireland-tax-benefits-to-apple-of-e13-billion/index.html" class="read-more dark"></a>
      </p>
    </div>
    <div class="news-content mobile">
      <p>
        The statement continued  that the Commission’s Apple Ireland tax avoiding case was ...        <a href="news/breaking-illegal-ireland-tax-benefits-to-apple-of-e13-billion/index.html" class="read-more dark"></a>
      </p>
    </div>
  </div>
        <div class="row">
          <div class="home-col-480 fl col-xs-12 col-sm-7">
            <!-- Market Analysis -->
              <div class="news-group">
    <h2 class="news-group-title">
      <a href="category/market-news/index.html">
        Market Analysis      </a>
    </h2>
		<?php if ( have_posts() ) : ?>
	<?php while ( have_posts() ) :$i++; the_post(); ?>
    <div class="news-list">
         <div class="news-item with-left-thumbnail">
          <div class="row">
            <div class="col-xs-4">
                  
			<?php the_post_thumbnail(); ?>
                                 
             </div>
            <div class="col-xs-8 np-left">
              <div class="news-content">
			    <?php the_title(); ?>
                 <?php the_excerpt(); ?>
                <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </div>
    </div>
	<?php endwhile; ?>
	<?php endif; ?>
  </div>

            <!-- Subscribe for exclusive updates -->
            <div class="green-box">
  <form method="POST" id="form-exclusive-updates" action="#">
    <h3>Subscribe to investorz Forex <span>exclusive updates!</span></h3>
    <div class="input-box">
      <input type="text" name="email" placeholder="Email" value="">
      <input type="button" class="subscribe-to-investorz" value="Submit">
    </div>
  </form>
</div>          </div>

          <!-- Ads -->
          <div class="home-col-300 fr col-xs-12 col-sm-5 ads-group home_right_adv">
            <!-- new -->
            <div id="execphp-74" class="widget widget_execphp">			<div class="execphpwidget"><a href="../external.html?link=http://goaff.trade360.com/visit/?bta=45015&amp;nci=5697" target="_Top"><img border="0" src="../external.html?link=http://trade360.ck-cdn.com/tn/serve/?cid=363846" width="300" height="250"></a></div>		</div><div id="execphp-75" class="widget widget_execphp">			<div class="execphpwidget"><a href="trading-tools/forex-indicators/index.html" target="_blank" title="Forex_Indicators"><img src="wp-content/uploads/2016/07/investorzForex-trading-tools.jpg" "="" width="331" height="323" border="0" alt="Indicators"></a></div>		</div><div id="execphp-76" class="widget widget_execphp">			<div class="execphpwidget"><a href="../external.html?link=http://www.ads-securities.co.uk/secure-broker/?utm_source=cpm&amp;utm_medium=broker-profile&amp;utm_campaign=2015-q4-investorzforex&amp;cmp=investorzforex" target="_blank"><img src="wp-content/uploads/2016/05/ADS-Securities-London-550x90.jpg"></a></div>		</div>          </div>
        </div>
      </div>
        
      <div class="home-col-480 sidebar fl col-xs-12 col-sm-4">
        <!-- Top Stories -->
        <div class="news-group top-stories">
          <h2 class="news-group-title">
            <a href="news/index.html">
              Top stories            </a>
          </h2>
          <div class="news-list">
                <div class="col-xs-12 col-lg-6 np-left border-on-right">
				
				<!-- neeraj changes -1 -->
      <div class="news-item featured">
                
       <p>Post1</p>
        
      </div>
    </div>
      <div class="col-xs-12 col-lg-6 np-right">
      <div class="news-item featured">
<p>Post2</p>
      </div>
    </div>
    <div class="clearfix"></div>
  <hr>
            <div class="other">
                        <div class="row">
        <?php while ( have_posts() ) :$i++; the_post(); ?>
		<div class="col-xs-12 col-lg-6">
		  <div class="news-item non-featured expanded">
      <?php
	   the_title();
	   the_post_thumbnail();
	   the_excerpt();
		?>
		
      </div>
	  
    </div>
	<?php endwhile; ?>
	  
              
          </div>


                  </div>
          </div>
          <div class="clearfix"></div>
        </div>

        <!-- Sponsored -->
            <div class="news-group sponsored-story">
      <div class="row">
        <div class="news-item with-left-thumbnail">
          <div class="col-xs-4">
                        <a class="news-image" href="news/fxgrow-account-types-introducing-ecn-vip/index.html" style="background-image: url('wp-content/uploads/2016/08/FXGROW-Account-types-139x90.jpg');"></a>
          </div>
          <div class="col-xs-8 np-left">
            <div class="news-content">
                <span class="sponsored-label">Sponsored</span>
                <h3><a href="news/fxgrow-account-types-introducing-ecn-vip/index.html">FXGrow account types - Introducing ECN VIP</a></h3>
                <p>The brokers constantly look for the new solutions that would entice the potentia...<a href="news/fxgrow-account-types-introducing-ecn-vip/index.html" class="read-more"></a></p>
                <span class="date fl">30 August 2016</span>
                <div class="clearfix"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>

        <!-- Widget Area -->
        <div class="ads-group">
          <div id="execphp-72" class="widget widget_execphp">			<div class="execphpwidget"></div>		</div>        </div>
      </div>
	  
	  <div class="home-col-480 sidebar fl col-xs-12 col-sm-4">
	 <?php get_sidebar(); ?>
	  </div> 
	  
	
	  
    </div>
    
    <!-- ROW 2 -->
    
	
    <!-- ROW 3 -->
    <div class="row mt-50">
      <!-- Watch it -->
      <div class="col-xs-12 col-sm-4 col-md-5">
        <div class="">
  <div class="news-group">
    <h2 class="news-group-title">
      <a href="forex-education/forex-video/index.html">
        Videos    </a>
    </h2>
    <div class="videos-list">
      <div class="row">
                    <div class="col-xs-12 col-lg-6">
             Blank Section
            </div>
                      <div class="col-xs-12 col-lg-6">
              <div class="video-item">
                    Blank Section
              </div>
            </div>
                      <div class="col-xs-12 col-lg-6">
              <div class="video-item">
                   Blank Section
              </div>
            </div>
                      <div class="col-xs-12 col-lg-6 visible-lg">
              <div class="video-item">
                     Blank Section
              </div>
            </div>
                      <div class="col-xs-12 col-lg-6 visible-lg">
              <div class="video-item">
                     Blank Section
              </div>
            </div>
                      <div class="col-xs-12 col-lg-6 visible-lg">
              <div class="video-item">
                    Blank Section
              </div>
            </div>
                    <div class="clearfix"></div>
              </div>
    </div>
  </div>
  <div class="clearfix"></div>
</div>      </div>
      <div class="col-xs-12 col-sm-8 col-md-7">
        <div class="row">
          <!-- Contributor Articles -->
          <div class="col-xs-12 col-sm-8 col-md-7">
            <div class="contributor-articles">
  <div class="news-group">
    <h2 class="news-group-title">
      <a href="category/guest-post/index.html">
          Blank Section </a>
    </h2>
    <div class="news-list">
              <div class="news-item featured">
                    Blank Image Section
					<br/>
                    <div class="news-content">
            Blank Section
          </div>
        </div>
                <div class="news-item">
            <div class="news-content">
          Blank Section
            </div>
          </div>
                  <div class="news-item">
            <div class="news-content">
              Blank Section
            </div>
          </div>
                  <div class="news-item">
            <div class="news-content">
           Blank Section
            </div>
          </div>
            </div>
  </div>
</div>          </div>

          <!-- Forum -->
          <div class="col-xs-12 col-sm-4 col-md-5">
                <div class="news-group forum-topics-list">
        <h2 class="news-group-title">
          <a href="forums/index.html">
            BInary Trading         </a>
        </h2>
        <div class="topics-list">
                            <div class="topic-item">
                   Blank Section
                </div>
                            <div class="topic-item">
                   Blank Section
                </div>
                            <div class="topic-item">
                 Blank Section
                    </div>
                </div>
                    </div>
    </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- ROW 4 -->
    <div class="row">
      <!-- Home mid-page ads -->
      <div class="hidden-xs col-sm-12 ads-group">
        <div class="home-mid-page-ads news-group row">
  <div id="execphp-71" class="widget widget_execphp">			<div class="execphpwidget"><div class="col-sm-6">
  <script async="" src="../pagead2.googlesyndication.com/pagead/js/f.txt"></script>
<!-- Glossary -->
<ins class="adsbygoogle" style="display: block; height: 60px;" data-ad-client="ca-pub-8925399288096184" data-ad-slot="1163347757" data-ad-format="auto" data-adsbygoogle-status="done"><ins id="aswift_0_expand" style="display:inline-table;border:none;height:60px;margin:0;padding:0;position:relative;visibility:visible;width:602px;background-color:transparent"><ins id="aswift_0_anchor" style="display:block;border:none;height:60px;margin:0;padding:0;position:relative;visibility:visible;width:602px;background-color:transparent"><iframe width="602" height="60" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no" allowfullscreen="true" onload="var i=this.id,s=window.google_iframe_oncopy,H=s&amp;&amp;s.handlers,h=H&amp;&amp;H[i],w=this.contentWindow,d;try{d=w.document}catch(e){}if(h&amp;&amp;d&amp;&amp;(!d.body||!d.body.firstChild)){if(h.call){setTimeout(h,0)}else if(h.match){try{h=s.upd(h,i)}catch(e){}w.location.replace(h)}}" id="aswift_0" name="aswift_0" style="left:0;position:absolute;top:0;"></iframe></ins></ins></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<div class="col-sm-6">
  <script async="" src="../pagead2.googlesyndication.com/pagead/js/f.txt"></script>
<!-- Glossary -->
<ins class="adsbygoogle" style="display: block; height: 60px;" data-ad-client="ca-pub-8925399288096184" data-ad-slot="1163347757" data-ad-format="auto" data-adsbygoogle-status="done"><ins id="aswift_1_expand" style="display:inline-table;border:none;height:60px;margin:0;padding:0;position:relative;visibility:visible;width:602px;background-color:transparent"><ins id="aswift_1_anchor" style="display:block;border:none;height:60px;margin:0;padding:0;position:relative;visibility:visible;width:602px;background-color:transparent"><iframe width="602" height="60" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no" allowfullscreen="true" onload="var i=this.id,s=window.google_iframe_oncopy,H=s&amp;&amp;s.handlers,h=H&amp;&amp;H[i],w=this.contentWindow,d;try{d=w.document}catch(e){}if(h&amp;&amp;d&amp;&amp;(!d.body||!d.body.firstChild)){if(h.call){setTimeout(h,0)}else if(h.match){try{h=s.upd(h,i)}catch(e){}w.location.replace(h)}}" id="aswift_1" name="aswift_1" style="left:0;position:absolute;top:0;"></iframe></ins></ins></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div></div>		</div>  <div class="clearfix"></div>
</div>      </div>
    </div>

    <!-- ROW 5 -->
    <div class="row">
      <div class="col-xs-12 col-sm-4 col-md-5">
        <!-- Trading tools -->
          <div class="news-group">
    <h2 class="news-group-title mb-5">
      <a href="trading-tools/index.html">
        Trading Tools      </a>
    </h2>
 <div class="simple-list">
              <div class="list-item">
          <a href="trading-tools/pip-calculator/index.html">
            <span class="text">Pip calculator</span>
          </a>
        </div>
              <div class="list-item">
          <a href="trading-tools/pivot-calculator/index.html">
            
          <span class="text">Pivot Point Calculator</span></a>
        </div>
              <div class="list-item">
          <a href="trading-tools/fibonacci-calculator/index.html">
            <span class="text">Fibonacci Calculator</span>
          </a>
        </div>
              <div class="list-item">
          <a href="trading-tools/forex-indicators/index.html">
            <span class="text">Indicators</span>
          </a>
        </div>
              
          </div>
		  </div>
  <div class="clearfix"></div>
      </div>
      
      <!-- Forex Bonus -->
      <div class="hidden-xs col-sm-8 col-md-7">
        <div class="row">
          <!-- Trading Indicators 7 strategies -->
          <div class="col-xs-12 col-sm-7 col-md-7">
                <div class="news-group">
        <h2 class="news-group-title mb-5">
          <a href="trading-tools/forex-indicators/index.html">
            Trading Indicators          </a>
        </h2>
        <div class="simple-list">
                            <div class="list-item">
                    <a href="indicators/3-sma-pip-machine/index.html">
                        <span class="text">3 SMA Pip Machine</span>
                    </a>
                </div>
                            <div class="list-item">
                    <a href="indicators/forex-ea-to-automatically-find-exit-points/index.html">
                        <span class="text">Forex EA to automatically find exit points</span>
                    </a>
                </div>
                            <div class="list-item">
                    <a href="indicators/forex-macd-trading-strategy-ea/index.html">
                        <span class="text">Forex MACD trading strategy EA</span>
                    </a>
                </div>
                            <div class="list-item">
                    <a href="indicators/pz-goldfinch-expert-advisor/index.html">
                        <span class="text">PZ Goldfinch Expert Advisor</span>
                    </a>
                </div>
                            <div class="list-item">
                    <a href="indicators/super-mega-winner-trading-strategy/index.html">
                        <span class="text">Super Mega Winner trading strategy</span>
                    </a>
                </div>
                    </div>
    </div>
    <div class="clearfix"></div>
          </div>

          <!-- Forex: Bonus-->
          <div class="col-xs-12 col-sm-4 col-md-5 hidden-xs hidden-sm">
            <div class="news-group ads-group">
  <h2 class="news-group-title">
Interviews</div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- ROW 6 -->
    <div class="row">
      <!-- Submit a story -->
      <!--
        <div class="col-xs-12 col-sm-4">
                  </div>
      -->
      
      <div class="col-xs-12 col-sm-8 col-md-7">
        
		
		
		<!-- Broker's Point -->
          <div class="news-group find-broker">
    <h2 class="news-group-title">
      <a href="directory/forex-brokers/index.html">
        Broker's Point      </a>
    </h2>
    <div class="brokers">
	
	


		
		 
	<?php	 
	$test = new WP_Query('type=post&category_name=Broker');
if($test->have_posts()):

while ($test-> have_posts() ) :$i++;$test-> the_post(); ?>
  
        <div class="col-xs-6 col-sm-4 col-md-3">
          <div class="news-group forex-brokers broker-single">
		 
		 <?php the_content()?>
		 
</div>

</div>
<?php endwhile;
endif;

wp_reset_postdata();

?>

	 </div>  

          </div>
    <div class="clearfix"></div>
  </div>
        <div class="hidden-xs col-sm-4 col-md-5" style="border:1px solid black;">
        <div class="news-group col-xs-12">

    <P>Twitter Widget</P>

    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

</div>



<div class="clearfix"></div>      </div>
        <div class="home-find-broker-ads news-group row">
          <div id="execphp-80" class="widget widget_execphp">			<div class="execphpwidget"><center><a href="../external.html?link=http://www.ads-securities.co.uk/secure-broker/?utm_source=cpm&amp;utm_medium=broker-profile&amp;utm_campaign=2015-q4-investorzforex&amp;cmp=investorzforex" target="_blank"><img src="wp-content/uploads/2016/08/spreadsB_aug_550x90_en.jpg" width="700" height="114"></a></center></div>		</div>          <div class="clearfix"></div>
        </div>

        <!-- Certify me -->
              </div>

      <!-- Tweets -->
      <div class="hidden-xs col-sm-4 col-md-5">
        <div class="news-group col-xs-12">

    <iframe id="twitter-widget-1" scrolling="no" frameborder="0" allowtransparency="true" allowfullscreen="true" class="twitter-timeline twitter-timeline-rendered" style="position: static; visibility: visible; display: inline-block; width: 520px; height: 330px; padding: 0px; border: none; max-width: 100%; min-width: 180px; margin-top: 0px; margin-bottom: 0px; min-height: 200px;" data-widget-id="728929975320125440" title="Twitter Timeline"></iframe>

    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

</div>



<div class="clearfix"></div>      </div>
    </div>
    
  </div>


<?php get_footer(); ?>