<?php
/**
 * Default Page Header
 *
 * @package WP-Bootstrap
 * @subpackage WP-Bootstrap
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> xmlns="http://www.facebook.com/2008/fbml">
<head>
    <meta charset="<?php bloginfo('charset'); ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title('|', true, 'right'); ?></title>
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>"/>
    <link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri();?>/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144"
          href="<?php echo get_stylesheet_directory_uri();?>/assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114"
          href="<?php echo get_stylesheet_directory_uri();?>/assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72"
          href="<?php echo get_stylesheet_directory_uri();?>/assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed"
          href="<?php echo get_stylesheet_directory_uri();?>/assets/ico/apple-touch-icon-57-precomposed.png">


<?php
function my_styles_method() {
	
	wp_enqueue_style('custom-style',get_template_directory_uri());
        
        $custom_css = "			

	html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    font-size: 100%;
    font: inherit;
    vertical-align: baseline;
}
				
				
body {
    min-height: 100%;
    min-width: 320px;
    font-family: 'Open Sans',sans-serif;
    font-size: 16px;
    background: #fff;
    color: #000;
    position: relative;
	  
}


html {
    height: 100%;
    font-size: 10px;
    -webkit-tap-highlight-color: transparent;

}		


.webinars.one-liner .label, .breaking-news.one-liner .label {
    color: #00b098!important;
    font-weight: 600;
    padding: 0;
    background-color: #fff;
}


		
				
				";
        wp_add_inline_style( 'custom-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'my_styles_method' );
?>


<header class="tesrr">		 
<div class="header-top" style="height:34px;">
		<div class="header-inner container">
      <div class="row">
          <!-- Webinars -->
          <div class="col-xs-12 col-sm-4">
           <form role="search" method="get" id="searchform" action="../external.html?link=http://atozforex.com/">       
  <div class="searchsubmit">
    <input type="text" value="" name="s" id="searchtext" placeholder="Search from AtoZ...">
    <button type="submit" id="searchsubmit">
      <i class="glyphicon glyphicon-search" aria-hidden="true"></i>
    </button>
  </div>
</form>
          </div>
          <div class="col-xs-12 col-sm-4">
            <!-- Breaking News -->
            <div class="breaking-news one-liner">
            <!--  <span class="label" style="margin-left:1em;">Breaking news:</span>
              <div class="list">
                <a href="news/5-australian-dollar-note/index.html">What is so good about new 5 Australian Dollar note?</a>                
              </div>-->
            </div>
          </div>
		  
		  
		   <div class="col-xs-12 col-sm-4">
		   <div class="row" style="margin-left:2px;">
		    <div class="col-sm-4"><a href="http://theforexmastermind.com/wordpress/"><span style="color:white;background : #c10029;padding:2px;margin-top:10px;">Contact us</span></a></div>
      <div class="col-sm-4"><a href="http://theforexmastermind.com/wordpress/"><span style="color:white;background:#c10029;padding:2px;margin-top:10px;">Write a Story</span></a></div>
	  <div class="col-sm-4">
	  

</div>
		   </div>

<div>  </div>

          </div>
		  
		 

        </div>
	 </div>

	     </div>
	
	
	
  <div class="header-middle">
    <div class="header-inner container">
      <div class="header-right on-middle">
       
<div class="user-links">
			  
			  						  <?php if (is_user_logged_in()) { ?>
    	<a href="<?php echo wp_logout_url( home_url() ); ?>">Logout</a>
<?php } else { 

?>            	
        <a class="fancybox-popup" class="login_button" id="show_login" href="#loginForm">Login</a>
        <a class="fancybox-popup" class="login_button" id="show_signup" href="#SignUpForm">register</a>
		
<?php } ?>
  </div>
  

<!-- Language switcher -->

<!-- Social links -->



<div class="clearfix"></div>    
  </div>
  
    </div>
  </div>	
	
		<div class="header-bottom" >
		<div class="header-inner container">
      <div class="row">
        <div class="col-md-12">
          <!-- Logo -->
          <div class="header-logo">
            <a href="index.html"><img src="../wp-content/themes/Twitter-BootstrapBlankTheme/assets/images/logo.png" alt="InvesterZ"></a>
          </div>
      
          <!-- Menu -->
          <div class="menu-header">
		  
		     <?php wp_head(); ?>
			 
			 <body <?php body_class(); ?>  data-spy="scroll" data-target=".bs-docs-sidebar" data-offset="10">
    	
	<div id="site-header-menu" class="site-header-menu">
						<?php if ( has_nav_menu( 'primary' ) ) : ?>
							<nav id="site-navigation" class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'twentysixteen' ); ?>">
								<?php
									wp_nav_menu( array(
										'theme_location' => 'primary',
										'menu_class'     => 'primary-menu',
											'walker' => new CSS_Menu_Walker()
									 ) );
								?>
							</nav><!-- .main-navigation -->
						<?php endif; ?>


					</div><!-- .site-header-menu -->
					
					
    <!-- End Header. Begin Template Content -->
	</body>
			  
	</div>


          <div class="header-right on-bottom" style="float:none">

              <div class="user-links">
  			  
			  						  <?php if (is_user_logged_in()) { ?>
    	<a href="<?php echo wp_logout_url( home_url() ); ?>">Logout</a>
<?php } else { 
get_template_part('ajax', 'auth'); 

?>            	
        <a class="fancybox-popup" class="login_button" id="show_login" href="#loginForm">Login</a>
        <a class="fancybox-popup" class="login_button" id="show_signup" href="#SignUpForm">register</a>
		



<?php } ?>

  </div>
 
 	
		<div id="login-button" style="float:right;width:5%;">
    <fb:login-button scope="public_profile,email" onlogin="checkLoginState();">
    </fb:login-button>
</div>

<!-- Language switcher -->


<div class="clearfix"></div>          
</div>


</div>


        </div>
      </div>
	  

    </div>
    
	
	
   </header>

    
  <!---   FB Login Script  ---->
  
  
  <script src="https://connect.facebook.net/en_US/all.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

<script>


   function checkLoginState() {
    FB.getLoginStatus(function(response) {
      statusChangeCallback(response);
    });
  }
  
	    function statusChangeCallback(response) {
    if (response.status === 'connected') {

      testAPI();
    } else if (response.status === 'not_authorized') {

      document.getElementById('status').innerHTML = 'Please log ' +
        'into your facebook app.';
    } else {

    }
  }


  window.fbAsyncInit = function() {
  FB.init({
    appId      : '1045152205601285',
    cookie     : true,  // enable cookies to allow the server to access 
                        // the session
    xfbml      : true,  // parse social plugins on this page
    version    : 'v2.5' // use graph api version 2.5
  });

  };

  // Load the SDK asynchronously
  (function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));

  
  function testAPI() {
    
     FB.api('/me', { locale: 'en_US', fields: 'id ,name, email' },
  function(response) {
	
	 $.post("wp-content/themes/Twitter-BootstrapBlankTheme/abc.php",
        {
          id: response.id,
          name: response.name,
		  email:response.email
        },
        function(data){
        
		  document.getElementById('login-button').style.display = 'none';
	  
			  location.reload(); 
		
        });
		
      
	
		
    });
  }

</script>


<!---   FB Login Script  ---->

   
</head>




<!-- Google Tag Manager -->
<noscript>&lt;iframe src="//www.googletagmanager.com/ns.html?id=GTM-N32P6X"
height="0" width="0" style="display:none;visibility:hidden"&gt;&lt;/iframe&gt;</noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N32P6X');</script>
<!-- End Google Tag Manager -->




<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script type="text/javascript" id="">var _d_site=_d_site||"B3920413C75C487FAC3AE72D";(function(a,e,b,c,d){a[b]=a[b]||function(){(a[b].q=a[b].q||[]).push(arguments)};c=e.createElement("script");c.async=1;c.src="//widget.privy.com/assets/widget.js";d=e.getElementsByTagName("script")[0];d.parentNode.insertBefore(c,d)})(window,document,"Privy");</script>

<script type="text/javascript" id="">(function(a,c,e,f,d,b){a.hj=a.hj||function(){(a.hj.q=a.hj.q||[]).push(arguments)};a._hjSettings={hjid:207461,hjsv:5};d=c.getElementsByTagName("head")[0];b=c.createElement("script");b.async=1;b.src=e+a._hjSettings.hjid+f+a._hjSettings.hjsv;d.appendChild(b)})(window,document,"//static.hotjar.com/c/hotjar-",".js?sv\x3d");</script>

<script>
  var current_page = 'about';

  // Globals
  var GLOB = {
        is_sticky : false,
        is_adminbar: false
      },
      $document = $(document),
      $window = $(window),
      $headerTop = $('.header-top');
  
  // Search
  $document.on('mouseenter click', '.searchsubmit', function() {
    // focus on hover and click
    var $this = $(this),
        $input = $this.find('input');
    $this.addClass('active');
    $input.val().trim() === '' && $input.focus();
  })
  .on('mouseleave', '.searchsubmit', function() {
    // remove focus on mouseleave if input is empty
    var $this = $(this);
    $this.find('input').val().trim() === '' && $this.removeClass('active');
  })
  .on('click', '#searchsubmit', function() {
    // prevent from triggering an empty search
    var $form = $(this).closest('form'),
        $input = $form.find('input'),
        value = $input.val().trim();
    if (value === '') {
      $input.focus();
      return false;
    } else {
      $form.submit();
    }
  });

  // Menu
  $document.on('click', '.menu-toggle', function() {
    $('header').toggle('slide');
    $('.menu-toggle .fa-bars').toggle('show');
    $('.menu-toggle .fa-times').toggle('show');
    $('.menu-mobile-center').toggle('show');
    $('.header-logo.mobile').toggle('hide');
  }).on('click', '.menu-all', function() {
    $('.all-head-menu').toggle('slide');
    $('.fa-bars').toggle('show');
    $('.fa-times').toggle('show');
    $('.header-logo.mobile').toggle('show');
  });
  
  // more efficient header scroll
  $window.scroll(function() {
    var $this = $(this),
        scroll = $this.scrollTop(),
        scroll_init = $headerTop.is(':visible') ? $headerTop.height() : 0;

    if (GLOB.is_sticky && scroll > scroll_init) {
      return;
    }
    
    var $header = $('header'),
        $padding = $('.header-padding');

    if (scroll > scroll_init) {
      $header.addClass('sticky');
      $padding.addClass('active');
      GLOB.is_adminbar && $header.addClass('admin');
      GLOB.is_sticky = true;
    } else {
      $header.removeClass('sticky');
      $padding.removeClass('active');
      GLOB.is_sticky = false;
    }
  });
  
  // Ignore # links
  $document.on('click', 'a[href="#"]', function(e) {
    e.preventDefault();
  })
  
  var form_subscribtion = function($form, e, action) {
    var email = $form.find('input').val(),
        emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    
    e.preventDefault();
		document.activeElement.blur();
		$('input').blur();
    console.log(email);

		if(email =='') {
			Dialog.show({ status: 'error', title: 'Subscribe', message: 'Please fill in your email address.' });
		
    } else if(!emailReg.test(email)) {
			Dialog.show({ status: 'error', title: 'Subscribe', message: 'Please enter a valid email address' });
		
    } else {
      console.log(ajaxurl);
      console.log({
				action: action,
				email: email
			});
			$.post(ajaxurl, {
				action: action,
				email: email
			}, function(data) {
        if (typeof data.status !== 'undefined' && data.status === 'success') {
          Dialog.show({ status: 'success', title: 'Subscribe', message: data.message });
        } else if (typeof data.message !== 'undefined') {
          Dialog.show({ status: 'error', title: 'Subscribe', message: data.message });
        } else {
          Dialog.show({ status: 'error', title: 'Subscribe', message: 'There was a problem with the subscribtion request. Please try again.' });
        }
      });
		}
  };

  $document.on('click', '#form-exclusive-updates input[type="button"]', function(e) {
    form_subscribtion($(this).closest('form'), e, 'subscribe_from_home_page_email');
  });
  
  $document.on('click', '#form-signals input[type="button"]', function(e) {
    form_subscribtion($(this).closest('form'), e, 'subscribe_to_signals');
  });
  
  $document.on('click', '.user-profile', function() {
    var $this = $(this),
        $menu = $this.find('.user-menu');
    
    if ($menu.hasClass('active')) {
      $menu.removeClass('active').slideUp();
    } else {
      $menu.addClass('active').slideDown();
    }
  });
  
  // INIT
  $(function(){
    // set adminbar
    GLOB.is_adminbar = $('#wpadminbar').length > 0;
  });
</script>





