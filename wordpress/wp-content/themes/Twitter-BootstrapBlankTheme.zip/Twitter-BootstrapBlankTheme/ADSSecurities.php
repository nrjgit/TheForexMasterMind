<?php /* Template Name: custompaget1*/ ?>

<?php get_header(); ?>


<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/atozforex.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.5.3"}};
			!function(a,b,c){function d(a){var c,d,e,f=b.createElement("canvas"),g=f.getContext&&f.getContext("2d"),h=String.fromCharCode;if(!g||!g.fillText)return!1;switch(g.textBaseline="top",g.font="600 32px Arial",a){case"flag":return g.fillText(h(55356,56806,55356,56826),0,0),f.toDataURL().length>3e3;case"diversity":return g.fillText(h(55356,57221),0,0),c=g.getImageData(16,16,1,1).data,d=c[0]+","+c[1]+","+c[2]+","+c[3],g.fillText(h(55356,57221,55356,57343),0,0),c=g.getImageData(16,16,1,1).data,e=c[0]+","+c[1]+","+c[2]+","+c[3],d!==e;case"simple":return g.fillText(h(55357,56835),0,0),0!==g.getImageData(16,16,1,1).data[0];case"unicode8":return g.fillText(h(55356,57135),0,0),0!==g.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script> 
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='bbp-default-group-css' href='http://atozforex.com/wp-content/plugins/bwp-minify/min/?f=wp-content/plugins/bbpress/templates/default/css/bbpress.css' type='text/css' media='screen' />
<link rel='stylesheet' id='responsive-lightbox-swipebox-group-css' href='http://atozforex.com/wp-content/plugins/bwp-minify/min/?f=wp-content/plugins/responsive-lightbox/assets/swipebox/css/swipebox.min.css,wp-content/plugins/wp-polls/polls-css.css,wp-content/plugins/wp-pagenavi/pagenavi-css.css,verstka/css/style.css,wp-content/themes/atoz_2016/dialog/dialog.css,verstka/css/fa.css' type='text/css' media='all' />
<style id='wp-polls-inline-css' type='text/css'>
.wp-polls .pollbar {
	margin: 1px;
	font-size: 6px;
	line-height: 8px;
	height: 8px;
	background-image: url('http://atozforex.com/wp-content/plugins/wp-polls/images/default/pollbg.gif');
	border: 1px solid #c8c8c8;
}

</style>
<script type='text/javascript' src='http://atozforex.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://atozforex.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mashnet = {"body":"","subject":""};
/* ]]> */
</script>
<script type='text/javascript' src='http://atozforex.com/wp-content/plugins/bwp-minify/min/?f=wp-content/plugins/mashshare-networks/assets/js/mashnet.min.js'></script>
<link rel='https://api.w.org/' href='http://atozforex.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://atozforex.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://atozforex.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.5.3" />
<link rel='shortlink' href='http://atozforex.com/?p=15789' />
<link rel="alternate" type="application/json+oembed" href="http://atozforex.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fatozforex.com%2Fdirectory%2Fads_securities_london%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://atozforex.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fatozforex.com%2Fdirectory%2Fads_securities_london%2F&#038;format=xml" />

  <link rel="icon" href="http://atozforex.com/wp-content/themes/atoz_2016/atoz-32.png" type="image/x-icon" />
  <link rel="favicon" href="http://atozforex.com/wp-content/themes/atoz_2016/atoz-32.png" type="image/x-icon" />
  <link rel="shortcut icon" href="http://atozforex.com/wp-content/themes/atoz_2016/atoz-32.png" type="image/x-icon" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:700,600,600italic,400" type="text/css" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" media="all" href="http://atozforex.com/wp-content/themes/atoz_2016/style.css" />
  <link rel="stylesheet" type="text/css" media="all" href="http://atozforex.com/wp-content/themes/atoz_2016/assets/css/bootstrap-grid.css" />
      <link rel="stylesheet" type="text/css" media="all" href="http://atozforex.com/wp-content/themes/atoz_2016/assets/css/home.css?seed=0.12441900 1472682752" />
    <script type='text/javascript'>
    /* <![CDATA[ */
    var calculators_ln = {"only_numbers":"Please enter only number in the input fields.","all_required":"All input values are required.","valid_number":"Please enter a valid number.","wrong_numbers":"The lower number can't be higher than the high number.","invalid_formula":"The selected formula is not valid"};
    /* ]]> */
  </script>
  <script type='text/javascript'>
    /* <![CDATA[ */
    var ln = {"error":"Error","success":"Success","info":"Info","dialog_close":"Close","dialog_confirm":"Confirm"};
    /* ]]> */
  </script>

  <!--[if lt IE 9]>
  <script>
      document.createElement('header');
      document.createElement('nav');
      document.createElement('section');
      document.createElement('article');
      document.createElement('aside');
      document.createElement('footer');
      document.createElement('time');
  </script>
  <![endif]-->

	<script type="text/javascript">
	    	    var ajaxurl = 'http://atozforex.com/wp-admin/admin-ajax.php';
	    var homeurl = 'http://atozforex.com';
	    var tplurl  = 'http://atozforex.com/wp-content/themes/atoz_2016';
	</script>

  <!--[if lt IE 9]><script>window.onload=function(){e("js/oldie/")}</script><![endif]-->
</head>
<body>

<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-N32P6X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N32P6X');</script>
<!-- End Google Tag Manager -->

<!--246248161-->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script>
  var current_page = 'brokers';

  // Globals
  var GLOB = {
        is_sticky : false,
        is_adminbar: false
      },
      $document = $(document),
      $window = $(window),
      $headerTop = $('.header-top');
  
  // Search
  $document.on('mouseenter click', '.searchsubmit', function() {
    // focus on hover and click
    var $this = $(this),
        $input = $this.find('input');
    $this.addClass('active');
    $input.val().trim() === '' && $input.focus();
  })
  .on('mouseleave', '.searchsubmit', function() {
    // remove focus on mouseleave if input is empty
    var $this = $(this);
    $this.find('input').val().trim() === '' && $this.removeClass('active');
  })
  .on('click', '#searchsubmit', function() {
    // prevent from triggering an empty search
    var $form = $(this).closest('form'),
        $input = $form.find('input'),
        value = $input.val().trim();
    if (value === '') {
      $input.focus();
      return false;
    } else {
      $form.submit();
    }
  });

  // Menu
  $document.on('click', '.menu-toggle', function() {
    $('header').toggle('slide');
    $('.menu-toggle .fa-bars').toggle('show');
    $('.menu-toggle .fa-times').toggle('show');
    $('.menu-mobile-center').toggle('show');
    $('.header-logo.mobile').toggle('hide');
  }).on('click', '.menu-all', function() {
    $('.all-head-menu').toggle('slide');
    $('.fa-bars').toggle('show');
    $('.fa-times').toggle('show');
    $('.header-logo.mobile').toggle('show');
  });
  
  // more efficient header scroll
  $window.scroll(function() {
    var $this = $(this),
        scroll = $this.scrollTop(),
        scroll_init = $headerTop.is(':visible') ? $headerTop.height() : 0;

    if (GLOB.is_sticky && scroll > scroll_init) {
      return;
    }
    
    var $header = $('header'),
        $padding = $('.header-padding');

    if (scroll > scroll_init) {
      $header.addClass('sticky');
      $padding.addClass('active');
      GLOB.is_adminbar && $header.addClass('admin');
      GLOB.is_sticky = true;
    } else {
      $header.removeClass('sticky');
      $padding.removeClass('active');
      GLOB.is_sticky = false;
    }
  });
  
  // Ignore # links
  $document.on('click', 'a[href="#"]', function(e) {
    e.preventDefault();
  })
  
  var form_subscribtion = function($form, e, action) {
    var email = $form.find('input').val(),
        emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    
    e.preventDefault();
		document.activeElement.blur();
		$('input').blur();
    console.log(email);

		if(email =='') {
			Dialog.show({ status: 'error', title: 'Subscribe', message: 'Please fill in your email address.' });
		
    } else if(!emailReg.test(email)) {
			Dialog.show({ status: 'error', title: 'Subscribe', message: 'Please enter a valid email address' });
		
    } else {
      console.log(ajaxurl);
      console.log({
				action: action,
				email: email
			});
			$.post(ajaxurl, {
				action: action,
				email: email
			}, function(data) {
        if (typeof data.status !== 'undefined' && data.status === 'success') {
          Dialog.show({ status: 'success', title: 'Subscribe', message: data.message });
        } else if (typeof data.message !== 'undefined') {
          Dialog.show({ status: 'error', title: 'Subscribe', message: data.message });
        } else {
          Dialog.show({ status: 'error', title: 'Subscribe', message: 'There was a problem with the subscribtion request. Please try again.' });
        }
      });
		}
  };

  $document.on('click', '#form-exclusive-updates input[type="button"]', function(e) {
    form_subscribtion($(this).closest('form'), e, 'subscribe_from_home_page_email');
  });
  
  $document.on('click', '#form-signals input[type="button"]', function(e) {
    form_subscribtion($(this).closest('form'), e, 'subscribe_to_signals');
  });
  
  $document.on('click', '.user-profile', function() {
    var $this = $(this),
        $menu = $this.find('.user-menu');
    
    if ($menu.hasClass('active')) {
      $menu.removeClass('active').slideUp();
    } else {
      $menu.addClass('active').slideDown();
    }
  });
  
  // INIT
  $(function(){
    // set adminbar
    GLOB.is_adminbar = $('#wpadminbar').length > 0;
  });
</script>

<script>
    function checkLoginReview()
    {
        var user_id = jQuery('#user_id').val();
        if ( 0 == user_id ) {
            $('div.loginForm-notification').html('You need log in to write a review.');
            $('a.sign-in-link').click();
            $('.loginForm-notification').slideDown( 100 );
        }
    }
</script>



<script type="text/javascript">
//    jQuery(document).ready(function () {
        var disqusPublicKey = "1KDxzlm6LqaaJk7C0eyATemhCg0U270riTBqKF0QNjyCCpflyHHsaJcDSKmxvfLB";
        var disqusShortname = "atozfx";
        var urlArray = [];
        jQuery('.disqus-crutches').each(function () {
            var url = jQuery(this).attr('data-disqus-url');
            urlArray.push('link:' + url);
        });

        jQuery.ajax({
            type: 'GET',
            url: "https://disqus.com/api/3.0/threads/set.jsonp",
            data: { api_key: disqusPublicKey, forum : disqusShortname, thread : urlArray }, // URL method
            cache: false,
            dataType: "jsonp",
            success: function (result) {
                for (var i in result.response) {
                    var countText = " comments";
                    var count = result.response[i].posts;
                    if (count == 1) countText = " comment";
                    jQuery('span[data-disqus-url="' + result.response[i].link + '"]').html(count);
                }
            }
        });

//    });
</script>

<script type="text/javascript">
    var widgetId1;
    var widgetId2;
    var onloadCallback = function() {
        // Renders the HTML element with id 'example1' as a reCAPTCHA widget.
        // The id of the reCAPTCHA widget is assigned to 'widgetId1'.
        widgetId1 = grecaptcha.render('captcha1', {
            'sitekey' : '6Ldt4xATAAAAABJa_pnHhkCzoLpzMBe3Nr7UBZMf',
            'theme' : 'dark'
        });

        widgetId2 = grecaptcha.render(document.getElementById('captcha2'), {
            'sitekey' : '6Ldt4xATAAAAABJa_pnHhkCzoLpzMBe3Nr7UBZMf',
            'theme' : 'light'
        });
    };
</script>

<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"
        async defer>
</script>





<div class="main brokerPage padding-main">
    <div class="container">
        <div class="brokerPage-row">
            <div class="brokerPage-content">


                <div class="gpadBlock mgBlock">
                    <div class="brokerHead">
                        <div class="brokerHead-logos">
                            <div class="column">
                                <div class="brokerHead-title">ADS Securities London</div>
                            </div>
                            <div class="column">
                                <img src="http://atozforex.com/wp-content/uploads/2015/11/ads-LOGO-167x43.png" alt="ADS Securities London" />
                            </div>
                        </div>
                        <div class="brokerHead-rating">
                            <div class="litRating">
                                <div class="litRating-inner">
                                    <div class="litRating-progress" style="width:80%;"></div>
                                    <img src="http://atozforex.com/verstka/images/litrting.png" alt="Rating"/>
                                    <div class="litRating-result">1 reviews</div>
                                </div>
                            </div>
                        </div>
                        <div class="brokerHead-content">
                            <p>Trading on margin involves a high level of risk</p>
                            <p><a href="http://" target="_blank"></a></p>
                        </div>
                        <div class="brokerHead-bottom">
                            <div class="column">

                                                                    <a href="https://my.ads-securities.co.uk/client-portal-web/uk/signup.html?utm_source=cpm&utm_medium=broker-profile&utm_campaign=2015-q4-atozforex&cmp=atozforex" target="_blank" class="btn btn-primary btn-md btn-border">OPEN LIVE ACCOUNT</a>
                                
                                                                    <a href="http://www.ads-securities.co.uk/accounts/demo-account/?utm_source=cpm&utm_medium=broker-profile&utm_campaign=2015-q4-atozforex&cmp=atozforex"  target="_blank" class="btn btn-danger btn-md btn-border">OPEN DEMO ACCOUNT</a>
                                
                            </div>
                            <div class="column">
                                <div class="socialBlock">
                                                                    </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mgBlock" style="text-align: center">

                    
                    <script>
                        window.twttr=(function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],t=window.twttr||{};if(d.getElementById(id))return;js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);t._e=[];t.ready=function(f){t._e.push(f);};return t;}(document,"script","twitter-wjs"));
                    </script>

                    <a href="https://twitter.com/share"
                       onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
                       data-count="none">
                        <img src="http://atozforex.com/verstka/images/soc-shares01.png" alt="Share via Twitter"/>
                    </a>

                    <a href="https://www.facebook.com/sharer/sharer.php?u=http://atozforex.com/directory/ads_securities_london/"
                       onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=500');return false;">
                        <img src="http://atozforex.com/verstka/images/soc-shares02.png" alt="Share via Facebook"/>
                    </a>

                    <a href="https://plus.google.com/share?url=http://atozforex.com/directory/ads_securities_london/"
                       onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
                        <img src="http://atozforex.com/verstka/images/soc-shares03.png" alt="Share via Google Plus"/>
                    </a>
                </div>

                <div class="gpadBlock mgBlock">
                    <div class="broker-text ctext">
                        <h5>DESCRIPTION</h5>
                        <a href="http://www.ads-securities.co.uk/accounts/demo-account/?utm_source=cpm&amp;utm_medium=broker-profile&amp;utm_campaign=2015-q4-atozforex&amp;cmp=atozforex" target="_blank">ADS Securities LondonÂ ( www.ads-securities.co.uk ) </a>uses new proprietary, "best-in-class" technology to access a mix of deep bank, non-bank and Middle East liquidity. This gives our clients excellent pricing, high quality execution and very good fill ratios. Â ADS Securities London is a wholly owned subsidiary of Abu Dhabi based ADS Holding LLC, and works in partnership with ADS Securities LLC, which is also a subsidiary of ADS Holding, to provide high quality trading solutions. ADS Securities LLC is regulated by the Central Bank of the UAE and was established in 2010 with paid up capital of US$400 million.                    </div>
                </div>

                <div class="mgBlock">
                    <div class="brokerAccordeon">
                                                    <div class="brokerAccordeon-item mgBlock open">
                                <div class="brokerAccordeon-item-head">
                                    <div class="column"><i class="icon icon_plmin">+</i></div>
                                    <div class="column"><i class="icon-sprite icon-accord-man"></i></div>
                                    <div class="column">Broker Information</div>
                                </div>
                                <div class="brokerAccordeon-item-body">
                                    <div class="brokerAccordeon-form zForm zNice">
                                        <form>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Broker</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="ADS Securities London Limited" data-title="ADS Securities London Limited" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">ADS Securities London Limited</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Broker URL</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="ADS-Securities.co.uk " data-title="ADS-Securities.co.uk " class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">ADS-Securities.co.uk </span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Headquarter Country</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="UK" data-title="UK" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">UK</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Headquarter City</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="London" data-title="London" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">London</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Year Founded</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="2014" data-title="2014" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">2014</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Country Presence</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="UK" data-title="UK" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">UK</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Regulation</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="FCA" data-title="FCA" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">FCA</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Type of Broker</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="STP, ECN" data-title="STP, ECN" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">STP, ECN</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Language</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="English, French, German, Italian, Russian, Spanish, Bulgarian, Hungarian, Polish, Portuguese, Serbian" data-title="English, French, German, Italian, Russian, Spanish, Bulgarian, Hungarian, Polish, Portuguese, Serbian" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">English, French, German, Italian, Russian, Spanish, Bulgarian, Hungarian, Polish, Portuguese, Serbian</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">US Clients</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="No" data-title="No" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">No</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Contact options  </span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Telephone, Email, Live Chat, Call back request, Mail" data-title="Telephone, Email, Live Chat, Call back request, Mail" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Telephone, Email, Live Chat, Call back request, Mail</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Public listing</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="N/A" data-title="N/A" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">N/A</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Technical Support</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="During European Session" data-title="During European Session" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">During European Session</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Spread betting</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Binary Options</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="No" data-title="No" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">No</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Blocked countries</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Afghanistan, Angola, Algeria, Belarus, Bosnia and Herzegovina, Cuba, DR Congo, Ecuador, Gaza Strip, Guyana, Guatemala, Iran, Iraq, Ivory Coast, North Korea, Kosovo, Liberia, Libya, Myanmar, Panama, Rwanda, Somalia, Sierra Leone, Sudan, Syria, Trinidad and Tobago, USA, Uganda, Yemen, Zimbabwe, Zambia" data-title="Afghanistan, Angola, Algeria, Belarus, Bosnia and Herzegovina, Cuba, DR Congo, Ecuador, Gaza Strip, Guyana, Guatemala, Iran, Iraq, Ivory Coast, North Korea, Kosovo, Liberia, Libya, Myanmar, Panama, Rwanda, Somalia, Sierra Leone, Sudan, Syria, Trinidad and Tobago, USA, Uganda, Yemen, Zimbabwe, Zambia" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Afghanistan, Angola, Algeria, Belarus, Bosnia and Herzegovina, Cuba, DR Congo, Ecuador, Gaza Strip, Guyana, Guatemala, Iran, Iraq, Ivory Coast, North Korea, Kosovo, Liberia, Libya, Myanmar, Panama, Rwanda, Somalia, Sierra Leone, Sudan, Syria, Trinidad and Tobago, USA, Uganda, Yemen, Zimbabwe, Zambia</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Accepted countries</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Albania, Algeria, Andorra, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cabo Verde, Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia, Comoros, Costa Rica, Cote d'Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, New Zealand, Nicaragua, Niger, Nigeria, North Korea, Norway, Oman, Pakistan, Palau, Palestine, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, St. Kitts and Nevis, St. Lucia, St. Vincent and The Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,  Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, South Korea, South Sudan, Spain, Sri Lanka,  Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Tunisia, Turkey, Turkmenistan, Tuvalu, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Vatican City, Venezuela, Vietnam" data-title="Albania, Algeria, Andorra, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cabo Verde, Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia, Comoros, Costa Rica, Cote d'Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, New Zealand, Nicaragua, Niger, Nigeria, North Korea, Norway, Oman, Pakistan, Palau, Palestine, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, St. Kitts and Nevis, St. Lucia, St. Vincent and The Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,  Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, South Korea, South Sudan, Spain, Sri Lanka,  Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Tunisia, Turkey, Turkmenistan, Tuvalu, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Vatican City, Venezuela, Vietnam" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Albania, Algeria, Andorra, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cabo Verde, Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia, Comoros, Costa Rica, Cote d'Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, New Zealand, Nicaragua, Niger, Nigeria, North Korea, Norway, Oman, Pakistan, Palau, Palestine, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, St. Kitts and Nevis, St. Lucia, St. Vincent and The Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,  Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, South Korea, South Sudan, Spain, Sri Lanka,  Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Tunisia, Turkey, Turkmenistan, Tuvalu, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Vatican City, Venezuela, Vietnam</span>
                                                    </div>
                                                </div>
                                                                                    </form>
                                    </div>
                                </div>
                            </div>
                        
                                                    <div class="brokerAccordeon-item mgBlock">
                                <div class="brokerAccordeon-item-head">
                                    <div class="column"><i class="icon icon_plmin">+</i></div>
                                    <div class="column"><i class="icon-sprite icon-accord-graph"></i></div>
                                    <div class="column">Trading Information</div>
                                </div>
                                <div class="brokerAccordeon-item-body">
                                    <div class="brokerAccordeon-form zForm zNice">
                                        <form>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Platform</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="MT4, OREX" data-title="MT4, OREX" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">MT4, OREX</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Platform timezone</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="GMT+2" data-title="GMT+2" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">GMT+2</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Commission</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Only on ECN Account" data-title="Only on ECN Account" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Only on ECN Account</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Spread</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Variable" data-title="Variable" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Variable</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Average Spread on EURUSD</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="0.0 < 1.0" data-title="0.0 < 1.0" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">0.0 < 1.0</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Average Spread on GBPUSD</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="0.0 < 1.0" data-title="0.0 < 1.0" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">0.0 < 1.0</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Average Spread on Gold </span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="$0.00 < $0.25" data-title="$0.00 < $0.25" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">$0.00 < $0.25</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Scalping</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Hedging</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Trailing Stop</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">OCO Orders  </span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">One Click Trading   </span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Fractional pip pricing</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Demo Account</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">Demo Account expiration</span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">EA compatible  </span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                            <div class="zForm-row rightFormat">
                                                    <div class="zForm-col">
                                                        <label><input type="checkbox" name="b1" checked="checked" disabled="disabled"/> <span class="zForm-text">All EA(s) allowed   </span></label>
                                                    </div>
                                                    <div class="zForm-col titleHover">
                                                        <input type="text" value="Yes" data-title="Yes" class="greyInput" disabled="disabled"/>
                                                        <span class="input-data">Yes</span>
                                                    </div>
                                                </div>
                                                                                    </form>
                                    </div>
                                </div>
                            </div>
                        
                        
                    </div>
                </div>


                
                                <div class="gpadBlock mgBlock videoBlock-wrap">
                    <div class="videoBlock-soc">
<!--                        <img src="--><!--images/videosoc.jpg" alt=""/>-->
                        
                        <script>
                            window.twttr=(function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],t=window.twttr||{};if(d.getElementById(id))return;js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);t._e=[];t.ready=function(f){t._e.push(f);};return t;}(document,"script","twitter-wjs"));
                        </script>

                        <a href="https://twitter.com/share"
                           onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
                           data-count="none">
                            <img src="http://atozforex.com/verstka/images/soc-shares01.png" alt="Share via Twitter"/>
                        </a>

                        <a href="https://www.facebook.com/sharer/sharer.php?u=http://atozforex.com/directory/ads_securities_london/"
                           onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=500');return false;">
                            <img src="http://atozforex.com/verstka/images/soc-shares02.png" alt="Share via Facebook"/>
                        </a>

                        <a href="https://plus.google.com/share?url=http://atozforex.com/directory/ads_securities_london/"
                           onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
                            <img src="http://atozforex.com/verstka/images/soc-shares03.png" alt="Share via Google Plus"/>
                        </a>
                    </div>
                    <div class="gpadBlock-title">The New Orex Optim</div>
                    <div class="videoBlock">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/DCQVlFGEHr8" frameborder="0" allowfullscreen></iframe>                    </div>
                </div>
                
                <div class="gpadBlock mgBlock">
                    <div class="compareBroker">
                        <div class="column">
                            <div class="gpadBlock-title">COMPARE WITH ANOTHER BROKER</div>
                        </div>
                        <div class="column">
                            <div class="zNice zForm">
                                <form id="compare-brokers">
                                    <input type="hidden" name="current-slug" value="ads_securities_london">
                                    <div class="zForm-row">
                                        <select id="compare-with">
                                                                                        <option value="0" disabled selected="selected">--------</option>
                                                                                                                                                                                                                                                                                                            <option value="fxgrow">FxGrow</option>
                                                                                                                                                                                                                <option value="icm-capital-limited">ICM Capital Limited</option>
                                                                                                                                                                                                                <option value="orbex">Orbex</option>
                                                                                                                                                                                                                <option value="fidelis-capital-markets">Fidelis CM</option>
                                                                                                                                                                                                                <option value="sto">STO</option>
                                                                                                                                                                                                                <option value="exness">Exness</option>
                                                                                                                                                                                                                <option value="plus500">Plus500</option>
                                                                                                                                                                                                                <option value="triomarkets">TrioMarkets</option>
                                                                                                                                                                                                                <option value="hy-markets">HY Markets</option>
                                                                                                                                                                                                                <option value="alpari">Alpari</option>
                                                                                                                                                                                                                <option value="acm-gold">ACM Gold</option>
                                                                                                                                                                                                                <option value="etoro">eToro</option>
                                                                                                                                                                                                                <option value="avatrade">AvaTrade</option>
                                                                                                                                                                                                                <option value="octafx">OctaFX</option>
                                                                                                                                                                                                                <option value="forextime">ForexTime</option>
                                                                                                                                                                                                                <option value="fxpro">FXPro</option>
                                                                                                                                                                                                                <option value="admiral-markets">Admiral Markets</option>
                                                                                                                                                                                                                <option value="xm">XM</option>
                                                                                                                                                                                                                <option value="fxprimus">FXPRIMUS</option>
                                                                                                                                                                                                                <option value="ironfx">IronFX</option>
                                                                                                                                                                                                                <option value="trade360">Trade360</option>
                                                                                                                                                                                                                <option value="acfx">ACFX (license suspended)</option>
                                                                                                                                                                                        </select>
                                    </div>
                                    <div class="zForm-row">
                                        <input type="submit" class="btn btn-primary btn-md btn-border" value="COMPARE NOW"/>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="gpadBlock darkGrey mgBlock">
                    <div class="contactUs">
                        <div class="contactUs-title">CONTACT US</div>
                        <div class="contactUs-subtitle">Contact us directly for further inquiries about our products and services.</div>
                        <div class="contactUs-form zForm zNice">
                            <form id="contact-with-broker">
                                <input type="hidden" id="broker-contact-us-id" value="15789">
                                <input type="hidden" id="broker-name" value="ADS Securities London">
                                <div class="column">
                                    <div class="zForm-row">
                                        <label>
                                            <span class="zForm-text">Name<span>*</span></span>
                                            <input type="text" id="broker-contact-us-name" name="text" class="darkBg" required="required"/>
                                        </label>
                                    </div>
                                    <div class="zForm-row">
                                        <label>
                                            <span class="zForm-text">Subject<span>*</span></span>
                                            <input type="text" id="broker-contact-us-subj" name="text1" class="darkBg" required="required"/>
                                        </label>
                                    </div>
                                    <div class="zForm-row">
                                        <label>
                                            <span class="zForm-text">Email<span>*</span></span>
                                            <input type="email" id="broker-contact-us-mail" name="text2" class="darkBg" placeholder="yoremail@gmail.com" required="required"/>
                                        </label>
                                    </div>
                                    <div class="zForm-row">
                                        <div id="captcha1"></div>
<!--                                        <div class="g-recaptcha" data-sitekey="6Ldt4xATAAAAABJa_pnHhkCzoLpzMBe3Nr7UBZMf"></div>-->
<!--                                        <label class="capcha-field">-->
<!--                                            <div class="zForm-col">-->
<!--                                                <span>Capcha</span>-->
<!--                                            </div>-->
<!--                                            <div class="zForm-col">-->
<!--                                                <input type="text" name="capcha1" class="darkBg" required="required" />-->
<!--                                            </div>-->
<!--                                        </label>-->
                                    </div>
                                </div>
                                <div class="column">
                                    <div class="zForm-row">
                                        <label>
                                            <span class="zForm-text">Message<span>*</span></span>
                                            <textarea rows="6" id="broker-contact-us-message" class="darkBg" required="required"></textarea>
                                        </label>
                                    </div>
                                    <div class="zForm-row text-right">
<!--                                        <input type="submit" class="btn btn-danger btn-md" value="SEND MESSAGE" />-->
                                        <button class="btn btn-danger btn-md" id="broker-contact-us-button">SEND MESSAGE</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>



                <div class="mgBlock brokerComments zNice">
                    <form id="review-add">
                        <input type="hidden" name="broker_id" id="broker_id" value="15789">
                        <input type="hidden" name="user_id" id="user_id" value="0">
                        <div class="brokerComments-row">
                            <div class="column">
                                <div class="broker-scam">
                                    Is ADS Securities London a scam?                                    <a href="#" data-scam="yes" data-broker-id="15789" class="btn btn-success btn-xs btn-darkgrey btn-border scam-review">YES</a>
                                    <a href="#" data-scam="no"  data-broker-id="15789" class="btn btn-success btn-xs btn-darkgrey btn-border scam-review">NO</a>
                                </div>
                            </div>
                            <div class="column">
                                <!-- <div class="litRating">
                                    <div class="litRating-inner">
                                        <div class="litRating-progress" style="width:80%;"></div>
                                        <img src="http://atozforex.com/verstka/images/litrtingwhite.png" alt="">
                                        <div class="litRating-result">1 reviews</div>
                                    </div>
                                </div> -->
                                <div class="broker-scam-numbers">
                                                                        <div>ADS Securities London is a Reliable Forex Broker <span id="scam-count-no">4</span></div>
                                    <div>ADS Securities London is a scam Forex Broker <span id="scam-count-yes">2</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="brokerComments-rating">
                            <input id="formRating" class="rating form-control hide notzNice" data-min="0" data-max="5" data-step="1" data-show-clear="false" data-show-caption="false"/>
                        </div>
                        <div class="brokerComments-textarea">
                            <textarea rows="2" placeholder="Write your review here" id="review_text" name="text" required="required" class="whiteGrey" onfocus="checkLoginReview(); return false;"></textarea>
                        </div>
                        <div class="zForm-row">
                            <div class="zForm-col">
                                <div id="captcha2"></div>
                            </div>
                            <div class="zForm-col">
                                <div class="text-right">
                                    <button id="review-add-button" class="btn btn-success btn-border btn-darkgrey">Write a review</button>
                                </div>
                            </div>
                        </div>
                    </form>


                                            <div class="brokerComment">
                            <div class="brokerComment-title">
                                <div class="litRating">
                                    <div class="litRating-inner">
                                        <div class="litRating-progress" style="width:80%;"></div>
                                        <img src="http://atozforex.com/verstka/images/litrtingwhite.png" alt="Rating">
                                    </div>
                                </div>
                                Jamie Forex Crawler                            </div>
                            <div class="brokerComment-date">
                                November 11, 2015                            </div>
                            <div class="brokerComment-text">
                                I am testing ADS Securities London with small deposit for withdrawing and spreads. So far Ads was fast. I will share my experience about other brokers too.
the part I liked especially was John calling me right after I opened my account and after I told him not to call me again he never called me again nor sent any pushing emails.
I like it so far.                            </div>
                            <div class="brokerComment-bottom">
<!--                                <a href="#">34 Comments</a><span class="lsep">| </span>  -->
                                Was this review helpful to you?                                <div class="brokerComment-bottom-buttons">
                                    <a href="#" data-helpfull="yes" data-review-id="16054" class="btn btn-success btn-xs btn-darkgrey btn-border helpfull-review">YES</a>
                                    <a href="#" data-helpfull="no"  data-review-id="16054" class="btn btn-success btn-xs btn-darkgrey btn-border helpfull-review">NO</a>
                                </div>
                            </div>
                        </div>
                    
                </div>
            </div>

            <div class="brokerPage-sidebar">

                                <div class="brokerSimilar">
                    <div class="brokerSimilar-wrap">
                        <div class="brokerSimilar-title">
                            SIMILAR FOREX BROKERS                        </div>
                        <div class="brokerSimilar-content">
                                                            <div class="column">
                                    <a href="http://atozforex.com/directory/fxpro/">
                                        <img src="http://atozforex.com/wp-content/uploads/2015/11/FxPro_General_Logo.png" alt="FXPro" />
                                    </a>
                                </div>
                                                            <div class="column">
                                    <a href="http://atozforex.com/directory/fxprimus/">
                                        <img src="http://atozforex.com/wp-content/uploads/2015/11/FxPrimus_logo.png" alt="FXPRIMUS" />
                                    </a>
                                </div>
                                                    </div>
                    </div>
                </div>
                
                                <div class="brokerNews">
                    <div class="brokerNews-slider">
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/ads-securities-london-offers-best-spread/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/07/ADS-Securities-London-1.png" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    August 2016                                </div>
                                <div class="brokerNews-item-text">
                                    ADS Securities London offers Best Spread? Compare it yourself!                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">1</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="ads-securities-london-offers-best-spread" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/ads-securities-london-offers-best-spread/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#ads-securities-london-offers-best-spread').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/ads-securities-london-offers-best-spread/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/ads-securities-executive-management-change/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/06/ADS.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    July 2016                                </div>
                                <div class="brokerNews-item-text">
                                    ADS Securities executive management change                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">76</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="ads-securities-executive-management-change" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/ads-securities-executive-management-change/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#ads-securities-executive-management-change').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/ads-securities-executive-management-change/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/post-brexit-ads-securities-london-what-next/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/06/Post-Brexit-ADS-Securities-London.png" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    June 2016                                </div>
                                <div class="brokerNews-item-text">
                                    Post Brexit ADS Securities London - What Next?                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">117</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="post-brexit-ads-securities-london-what-next" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/post-brexit-ads-securities-london-what-next/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#post-brexit-ads-securities-london-what-next').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/post-brexit-ads-securities-london-what-next/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/live-brexit-updates/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/06/live-brexit-updates.png" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    June 2016                                </div>
                                <div class="brokerNews-item-text">
                                    Live Brexit Updates (Big Picture)                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">1333</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="live-brexit-updates" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/live-brexit-updates/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#live-brexit-updates').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/live-brexit-updates/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/list-of-forex-brokers-brexit-risk-management-strategies/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/06/Forex-Brokers-Brexit-Risk-Management1.png" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    June 2016                                </div>
                                <div class="brokerNews-item-text">
                                    List of Forex Brokers Brexit Risk management Strategies                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">1322</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="list-of-forex-brokers-brexit-risk-management-strategies" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/list-of-forex-brokers-brexit-risk-management-strategies/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#list-of-forex-brokers-brexit-risk-management-strategies').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/list-of-forex-brokers-brexit-risk-management-strategies/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/ads-securities-sfc-licenses-acquired-type-12/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/06/ADS.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    June 2016                                </div>
                                <div class="brokerNews-item-text">
                                    ADS Securities SFC Licenses Acquired - Type 1&2                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">145</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="ads-securities-sfc-licenses-acquired-type-12" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/ads-securities-sfc-licenses-acquired-type-12/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#ads-securities-sfc-licenses-acquired-type-12').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/ads-securities-sfc-licenses-acquired-type-12/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/best-islamic-forex-broker-award-presented-ads-securities/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/05/ADS-Securities-AtoZ-Forex-Awards.png" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    May 2016                                </div>
                                <div class="brokerNews-item-text">
                                    Best Islamic Forex Broker Award Presented to ADS Securities                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">223</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="best-islamic-forex-broker-award-presented-ads-securities" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/best-islamic-forex-broker-award-presented-ads-securities/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#best-islamic-forex-broker-award-presented-ads-securities').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/best-islamic-forex-broker-award-presented-ads-securities/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/ads-securities-london-market-scanner-launched-for-mt4/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/05/ADS-Securities-London-launches-Market-Scanner.png" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    May 2016                                </div>
                                <div class="brokerNews-item-text">
                                    ADS Securities London Market Scanner launched for MT4                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">271</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="ads-securities-london-market-scanner-launched-for-mt4" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/ads-securities-london-market-scanner-launched-for-mt4/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#ads-securities-london-market-scanner-launched-for-mt4').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/ads-securities-london-market-scanner-launched-for-mt4/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/ads-securities-arabic-language-trading-app-launch/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/05/ADS-Securities-Arabic-Language-Trading-App.png" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    May 2016                                </div>
                                <div class="brokerNews-item-text">
                                    ADS Securities Arabic Language Trading App launch                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">364</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="ads-securities-arabic-language-trading-app-launch" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/ads-securities-arabic-language-trading-app-launch/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#ads-securities-arabic-language-trading-app-launch').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/ads-securities-arabic-language-trading-app-launch/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/how-to-trade-forex-after-ecb-announcement/">
                                    <img src="http://atozforex.com/wp-content/uploads/2016/03/18.png" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    March 2016                                </div>
                                <div class="brokerNews-item-text">
                                    How to trade Forex after ECB announcement                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">347</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="how-to-trade-forex-after-ecb-announcement" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/how-to-trade-forex-after-ecb-announcement/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#how-to-trade-forex-after-ecb-announcement').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/how-to-trade-forex-after-ecb-announcement/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/broken-monetary-policy-divergence-video/">
                                    <img src="http://atozforex.com/wp-content/uploads/2015/02/MOnetary-divergence.png" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    February 2016                                </div>
                                <div class="brokerNews-item-text">
                                    Broken Monetary Policy Divergence (video)                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">445</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="broken-monetary-policy-divergence-video" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/broken-monetary-policy-divergence-video/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#broken-monetary-policy-divergence-video').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/broken-monetary-policy-divergence-video/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="brokerNews-item">
                            <div class="brokerNews-item-img">
                                <a href="http://atozforex.com/news/usd-strength-fibonacci-outlook/">
                                    <img src="http://atozforex.com/wp-content/uploads/2015/03/finance-mario-draghi-e1471627741478.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="brokerNews-item-bottom">
                                <div class="brokerNews-item-title">
                                    Company News                                </div>
                                <div class="brokerNews-item-date">
                                    February 2016                                </div>
                                <div class="brokerNews-item-text">
                                    USD strength &amp; Fibonacci outlook (video)                                </div>
                                <div class="gsocialBlock">
                                    <div class="gsocialBlock-item">
                                                                                <a href="#" class="icon-sprite icon-eye"></a> <span class="gsocialBlock-item-count">1302</span>
                                    </div>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-heart"></a> <span id="usd-strength-fibonacci-outlook" class="gsocialBlock-item-count">0</span>
                                    </div>
                                    <script>
                                        (function($){
                                            jQuery.sharedCount = function(url, fn) {
                                                //url = encodeURIComponent(url || location.href);
                                                url = "http://atozforex.com/news/usd-strength-fibonacci-outlook/";
                                                var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                                var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                                var arg = {
                                                    data: {
                                                        url: url,
                                                        apikey: apikey
                                                    },
                                                    url: domain + "/url",
                                                    cache: true,
                                                    dataType: "json"
                                                };
                                                if ('withCredentials' in new XMLHttpRequest) {
                                                    arg.success = fn;
                                                } else {
                                                    var cb = "sc_" + url.replace(/\W/g, '');
                                                    window[cb] = fn;
                                                    arg.jsonpCallback = cb;
                                                    arg.dataType += "p";
                                                }
                                                return jQuery.ajax(arg);
                                            };
                                            jQuery.sharedCount(location.href, function(data){
                                                jQuery('#usd-strength-fibonacci-outlook').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                            });
                                        })(jQuery);
                                    </script>
                                    <div class="gsocialBlock-item">
                                        <a href="#" class="icon-sprite icon-talk-cloud"></a> <span class="disqus-crutches" data-disqus-url="http://atozforex.com/news/usd-strength-fibonacci-outlook/">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                                            </div>
                </div>
                
                                <div class="brokerPlatform">
                    <div class="gTitleBlock">
                        <div class="gTitleBlock-title">
                            PLATFORMS                        </div>
                        <div class="gTitleBlock-content">
                            <div class="chartBlock">
                                <div class="tab-content">
                                                                                                                <div class="tab-pane active" id="Orex_Optim">
                                            <a href="http://www.ads-securities.co.uk/accounts/demo-account/?utm_source=cpm&utm_medium=broker-profile&utm_campaign=2015-q4-atozforex&cmp=atozforex"  target="_blank">
                                                <img src="http://atozforex.com/wp-content/uploads/2015/11/Orex.jpg" alt="Orex Optim"/>
                                            </a>
                                        </div>
                                                                                                                    <div class="tab-pane " id="MT4">
                                            <a href="http://www.ads-securities.co.uk/accounts/demo-account/?utm_source=cpm&utm_medium=broker-profile&utm_campaign=2015-q4-atozforex&cmp=atozforex"  target="_blank">
                                                <img src="http://atozforex.com/wp-content/uploads/2015/11/ADS-MT4.png" alt="MT4"/>
                                            </a>
                                        </div>
                                                                                                            </div>
                            </div>
                        </div>
                        <div class="gTitleBlock-bottom">
                            <ul class="nav nav-tabs" id="myTab">
                                                                                                    <li class="active"><a href="#Orex_Optim" class="btn btn-success btn-xs btn-valign active"><span>Orex Optim</span></a></li>
                                                                                                        <li><a href="#MT4" class="btn btn-success btn-xs btn-valign"><span>MT4</span></a></li>
                                                                                                </ul>
                        </div>
                    </div>
                </div>
                
                
                
                                <div class="zTabs brokerTabs">
                    <div class="gTitleBlock">
                        <div class="gTitleBlock-title">
                            EDUCATION                        </div>
                        <div class="gTitleBlock-content">

                                                        <div class="zTabs-window" data-zTab="1">
                                <div class="brokerTabs-img">
                                    <a href="http://www.ads-securities.co.uk/learn/ebook/free-chart-trading-guide/?utm_source=cpm&utm_medium=atoz-ebook&utm_campaign=2015-q4-atozforex&cmp=atozforex">
                                        <img src="http://atozforex.com/wp-content/uploads/2015/11/Chart-Trading-guide-332x164.png" alt="Chart Trading Guide"/>
                                    </a>
                                    <div class="brokerTabs-text">
                                        <p>Chart Trading Guide provides an in-depth understanding of how charts can be used effectively when you trade.</p>
                                        <p><a target="_blank" href="http://www.ads-securities.co.uk/learn/ebook/free-chart-trading-guide/?utm_source=cpm&utm_medium=atoz-ebook&utm_campaign=2015-q4-atozforex&cmp=atozforex" class="morelink">Chart Trading Guide</a></p>
                                    </div>
                                </div>
                            </div>
                            
                                                        <div class="zTabs-window" data-zTab="2">
                                <a href="http://atozforex.com/webinars/5-professional-price-action-tools-free-training/">
                                    <img src="http://atozforex.com/wp-content/uploads/2014/08/CandlestickBasicsChart.gif" alt="5 Professional Price Action tools &ndash; Free Training 2nd part"/>
                                </a>
                                <div class="brokerTabs-text">
                                    <div id="attachment_20265" style="width: 1073px" class="wp-caption aligncenter"><a href="http://atozforex.com/wp-content/uploads/2016/05/It-is-easier-to-follow-the-trend.png"><img class="size-full wp-image-20265" src="http://atozforex.com/wp-content/uploads/2016/05/It-is-easier-to-follow-the-trend.png" alt="It is easier to follow the trend - AtoZForex.com" width="1063" height="406" /></a><p class="wp-caption-text">It is easier to follow the trend</p></div>
                                    <p><a target="_blank" href="http://atozforex.com/webinars/5-professional-price-action-tools-free-training/" class="morelink">5 Professional Price Action tools â€“ Free Training 2nd part</a></p>
                                </div>
                            </div>
                            
                        </div>
                        <div class="gTitleBlock-buttons">

                                                        <div class="gTitleBlock-button" data-zTabId="1">
                                <div class="tabs-icon-wrapper">
                                    <div class="icon icon_ebook"></div>
                                </div>
                                <div class="gTitleBlock-buttons-text">eBOOKS</div>
                                <div class="morelinkBlock"><a href="/ebooks/" class="morelink">More</a></div>
                            </div>
                            
                                                        <div class="gTitleBlock-button" data-zTabId="2">
                                <div class="tabs-icon-wrapper">
                                    <div class="icon icon_webinar"></div>
                                </div>
                                <div class="gTitleBlock-buttons-text">WEBINARS</div>
                                <div class="morelinkBlock"><a href="/webinars/" class="morelink">More</a></div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
                <div class="zTabs brokerSubscribe">
                    <div class="gTitleBlock">
                        <div class="gTitleBlock-title">
                            JOIN THE NEWSLETTER                        </div>
                        <div class="gTitleBlock-content">
                            <div class="zForm zNice">
                                <form id="join-the-newsletter">
                                    <div class="zForm-row">
                                        <input type="email" class="whiteInput" data-image="http://atozforex.com/verstka/images/icon_mess.png" name="email" placeholder="youremail@gmail.com" required="required" id="newsletter-email"/>
                                    </div>
                                    <div class="zForm-row buttonRow">
                                        <input type="submit" class="btn btn-danger btn-md" value="SUBSCRIBE NOW" />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>



<?php get_sidebar(); ?>
<?php get_footer(); ?>

























<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			// End of the loop.
		endwhile;
		?>

	</main><!-- .site-main -->

	<?php get_sidebar( 'content-bottom' ); ?>

</div><!-- .content-area -->

