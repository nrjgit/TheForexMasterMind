<?php

function understrap_posted_on() {}



function understrap_entry_footer() {
	
}



