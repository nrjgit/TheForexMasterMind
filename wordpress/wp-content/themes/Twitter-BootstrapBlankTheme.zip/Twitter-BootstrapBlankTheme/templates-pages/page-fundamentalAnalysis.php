<?php /* Template Name: Fundamental Analysis */ ?>

<?php get_header(); ?>


<script id="facebook-jssdk" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&amp;version=v2.7"></script><script id="twitter-wjs" src="https://platform.twitter.com/widgets.js"></script><script async="" src="//www.google-analytics.com/analytics.js"></script><script async="" src="//widget.privy.com/assets/widget.js"></script><script type="text/javascript" async="" src="http://www.google-analytics.com/analytics.js"></script><script type="text/javascript" async="" src="http://a.adroll.com/j/roundtrip.js"></script><script async="" src="//www.googletagmanager.com/gtm.js?id=GTM-N32P6X"></script><script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/investorz.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.5.4"}};
			!function(a,b,c){function d(a){var c,d,e,f=b.createElement("canvas"),g=f.getContext&&f.getContext("2d"),h=String.fromCharCode;if(!g||!g.fillText)return!1;switch(g.textBaseline="top",g.font="600 32px Arial",a){case"flag":return g.fillText(h(55356,56806,55356,56826),0,0),f.toDataURL().length>3e3;case"diversity":return g.fillText(h(55356,57221),0,0),c=g.getImageData(16,16,1,1).data,d=c[0]+","+c[1]+","+c[2]+","+c[3],g.fillText(h(55356,57221,55356,57343),0,0),c=g.getImageData(16,16,1,1).data,e=c[0]+","+c[1]+","+c[2]+","+c[3],d!==e;case"simple":return g.fillText(h(55357,56835),0,0),0!==g.getImageData(16,16,1,1).data[0];case"unicode8":return g.fillText(h(55356,57135),0,0),0!==g.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="http://investorz.com/wp-includes/js/wp-emoji-release.min.js?ver=4.5.4" type="text/javascript"></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" id="bbp-default-group-css" href="http://investorz.com/wp-content/plugins/bwp-minify/min/?f=wp-content/plugins/bbpress/templates/default/css/bbpress.css" type="text/css" media="screen">
<link rel="stylesheet" id="responsive-lightbox-swipebox-group-css" href="http://investorz.com/wp-content/plugins/bwp-minify/min/?f=wp-content/plugins/responsive-lightbox/assets/swipebox/css/swipebox.min.css,wp-content/plugins/wp-polls/polls-css.css,wp-content/plugins/wp-pagenavi/pagenavi-css.css,verstka/css/style.css,wp-content/themes/investorz_2016/dialog/dialog.css,verstka/css/fa.css" type="text/css" media="all">
<style id="wp-polls-inline-css" type="text/css">
.wp-polls .pollbar {
	margin: 1px;
	font-size: 6px;
	line-height: 8px;
	height: 8px;
	background-image: url('http://investorz.com/wp-content/plugins/wp-polls/images/default/pollbg.gif');
	border: 1px solid #c8c8c8;
}

</style>
<script type="text/javascript" src="http://investorz.com/wp-includes/js/jquery/jquery.js?ver=1.12.4"></script>
<script type="text/javascript" src="http://investorz.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>
<script type="text/javascript">
/* <![CDATA[ */
var mashnet = {"body":"","subject":""};
/* ]]> */
</script>
<script type="text/javascript" src="http://investorz.com/wp-content/plugins/bwp-minify/min/?f=wp-content/plugins/mashshare-networks/assets/js/mashnet.min.js"></script>
<link rel="https://api.w.org/" href="http://investorz.com/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://investorz.com/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://investorz.com/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 4.5.4">

  <link rel="icon" href="http://investorz.com/wp-content/themes/investorz_2016/investorz-32.png" type="image/x-icon">
  <link rel="favicon" href="http://investorz.com/wp-content/themes/investorz_2016/investorz-32.png" type="image/x-icon">
  <link rel="shortcut icon" href="http://investorz.com/wp-content/themes/investorz_2016/investorz-32.png" type="image/x-icon">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:700,600,600italic,400" type="text/css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" media="all" href="http://investorz.com/wp-content/themes/investorz_2016/style.css">
  <link rel="stylesheet" type="text/css" media="all" href="http://investorz.com/wp-content/themes/investorz_2016/assets/css/bootstrap-grid.css">
      <link rel="stylesheet" type="text/css" media="all" href="http://investorz.com/wp-content/themes/investorz_2016/assets/css/home.css?seed=0.20685400 1473470496">
    <script type="text/javascript">
    /* <![CDATA[ */
    var calculators_ln = {"only_numbers":"Please enter only number in the input fields.","all_required":"All input values are required.","valid_number":"Please enter a valid number.","wrong_numbers":"The lower number can't be higher than the high number.","invalid_formula":"The selected formula is not valid"};
    /* ]]> */
  </script>
  <script type="text/javascript">
    /* <![CDATA[ */
    var ln = {"error":"Error","success":"Success","info":"Info","dialog_close":"Close","dialog_confirm":"Confirm"};
    /* ]]> */
  </script>

  <!--[if lt IE 9]>
  <script>
      document.createElement('header');
      document.createElement('nav');
      document.createElement('section');
      document.createElement('article');
      document.createElement('aside');
      document.createElement('footer');
      document.createElement('time');
  </script>
  <![endif]-->

	<script type="text/javascript">
	    	    var ajaxurl = 'http://investorz.com/wp-admin/admin-ajax.php';
	    var homeurl = 'http://investorz.com';
	    var tplurl  = 'http://investorz.com/wp-content/themes/investorz_2016';
	</script>

  <!--[if lt IE 9]><script>window.onload=function(){e("js/oldie/")}</script><![endif]-->
<script async="" src="//static.hotjar.com/c/hotjar-207461.js?sv=5"></script><meta http-equiv="X-UA-Compatible" content="IE=edge"><link href="//fonts.googleapis.com/css?family=Lato:300,400,700|Open+Sans:400italic,400,700,600,300" rel="stylesheet" type="text/css"><style id="widget-css">@import 'http://assets.privy.com/assets/widget-09f5f9cea7f45de5c1bef89dd72f10dd8393cb6651c3d60a1dc9abed3abe9279.css';</style><script async="true" type="text/javascript" src="https://d.adroll.com/pixel/FQCOBTAYLNBHVGUTUONU4X/FGYXGWXJ6JDPHNVVI5VYMJ?pv=99500386773.59518&amp;cookie=FQCOBTAYLNBHVGUTUONU4X%3A32%7CFGYXGWXJ6JDPHNVVI5VYMJ%3A32%7CFQ3GSONBCVB4FG4CDCUWHL%3A32&amp;adroll_s_ref=http%3A//investorz.com/&amp;keyw="></script><script src="https://script.hotjar.com/modules-3a655ad13238f38c608ff3a95a7cb46a.js"></script><script type="text/javascript" charset="utf-8" async="" src="https://platform.twitter.com/js/button.e17e434ecfb12438c31724873d54e4cd.js"></script><div style="width: 1px; height: 1px; display: inline; position: absolute;"><img height="1" width="1" style="border-style:none;" alt="" src="http://d.adroll.com/cm/r/out">
<img height="1" width="1" style="border-style:none;" alt="" src="http://d.adroll.com/cm/f/out">
<img height="1" width="1" style="border-style:none;" alt="" src="http://d.adroll.com/cm/b/out">
<img height="1" width="1" style="border-style:none;" alt="" src="http://d.adroll.com/cm/w/out">
<img height="1" width="1" style="border-style:none;" alt="" src="http://d.adroll.com/cm/x/out">
<img height="1" width="1" style="border-style:none;" alt="" src="http://d.adroll.com/cm/l/out">
<img height="1" width="1" style="border-style:none;" alt="" src="http://d.adroll.com/cm/o/out">
<img height="1" width="1" style="border-style:none;" alt="" src="http://d.adroll.com/cm/g/out?google_nid=adroll5">
</div><style type="text/css">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}.fb_link img{border:none}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_reset .fb_dialog_legacy{overflow:visible}.fb_dialog_advanced{padding:10px;-moz-border-radius:8px;-webkit-border-radius:8px;border-radius:8px}.fb_dialog_content{background:#fff;color:#333}.fb_dialog_close_icon{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;_background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yL/r/s816eWC-2sl.gif);cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{top:5px;left:5px;right:auto}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent;_background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yL/r/s816eWC-2sl.gif)}.fb_dialog_close_icon:active{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent;_background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yL/r/s816eWC-2sl.gif)}.fb_dialog_loader{background-color:#f6f7f9;border:1px solid #606060;font-size:24px;padding:20px}.fb_dialog_top_left,.fb_dialog_top_right,.fb_dialog_bottom_left,.fb_dialog_bottom_right{height:10px;width:10px;overflow:hidden;position:absolute}.fb_dialog_top_left{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 0;left:-10px;top:-10px}.fb_dialog_top_right{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -10px;right:-10px;top:-10px}.fb_dialog_bottom_left{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -20px;bottom:-10px;left:-10px}.fb_dialog_bottom_right{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -30px;right:-10px;bottom:-10px}.fb_dialog_vert_left,.fb_dialog_vert_right,.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{position:absolute;background:#525252;filter:alpha(opacity=70);opacity:.7}.fb_dialog_vert_left,.fb_dialog_vert_right{width:10px;height:100%}.fb_dialog_vert_left{margin-left:-10px}.fb_dialog_vert_right{right:0;margin-right:-10px}.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{width:100%;height:10px}.fb_dialog_horiz_top{margin-top:-10px}.fb_dialog_horiz_bottom{bottom:0;margin-bottom:-10px}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{-webkit-transform:none;height:100%;margin:0;overflow:visible;position:absolute;top:-10000px;left:0;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{width:auto;height:auto;min-height:initial;min-width:initial;background:none}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{color:#fff;display:block;padding-top:20px;clear:both;font-size:18px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .45);position:absolute;bottom:0;left:0;right:0;top:0;width:100%;min-height:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_content .dialog_header{-webkit-box-shadow:white 0 1px 1px -1px inset;background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#738ABA), to(#2C4987));border-bottom:1px solid;border-color:#1d4088;color:#fff;font:14px Helvetica, sans-serif;font-weight:bold;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{-webkit-font-smoothing:subpixel-antialiased;height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#4966A6), color-stop(.5, #355492), to(#2A4887));border:1px solid #29487d;-webkit-background-clip:padding-box;-webkit-border-radius:3px;-webkit-box-shadow:rgba(0, 0, 0, .117188) 0 1px 1px inset, rgba(255, 255, 255, .167969) 0 1px 0;display:inline-block;margin-top:3px;max-width:85px;line-height:18px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{border:none;background:none;color:#fff;font:12px Helvetica, sans-serif;font-weight:bold;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #555;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f6f7f9;border:1px solid #555;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-repeat:no-repeat;background-position:50% 50%;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_hide_iframes iframe{position:relative;left:-10000px}.fb_iframe_widget_loader{position:relative;display:inline-block}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}.fb_iframe_widget_loader iframe{min-height:32px;z-index:2;zoom:1}.fb_iframe_widget_loader .FB_Loader{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat;height:32px;width:32px;margin-left:-16px;position:absolute;left:50%;z-index:4}</style><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="a25489e9-848c-4356-97ff-161b0852c509/service" src="//sumome-140a.kxcdn.com/virtual/58bafef80dd89d4454f3b3bd51564ca5ae0dc84d/client/js/a25489e9-848c-4356-97ff-161b0852c509/service.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="8dc42610-ae42-4164-90b1-573478b46574/service" src="//sumome-140a.kxcdn.com/virtual/bef4fd2253b41d6b41681d8c49d9cb92a611ec69/client/js/8dc42610-ae42-4164-90b1-573478b46574/service.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="2c40add5-3570-45d7-8212-8fc2942f7f74/service" src="//sumome-140a.kxcdn.com/virtual/e556cb4eedb63d42d422c0a71344a6c98fe42d5e/client/js/2c40add5-3570-45d7-8212-8fc2942f7f74/service.js"></script><link type="text/css" rel="stylesheet" href="//sumome-140a.kxcdn.com/virtual/89d5c99fb26b92e56c1fbe44ef83b93bf381b690/client/js/../css/sme-popup.css"><style id="__web-inspector-hide-shortcut-style__" type="text/css">
.__web-inspector-hide-shortcut__, .__web-inspector-hide-shortcut__ *, .__web-inspector-hidebefore-shortcut__::before, .__web-inspector-hideafter-shortcut__::after
{
    visibility: hidden !important;
}
</style>






<!-- Google Tag Manager -->
<noscript>&lt;iframe src="//www.googletagmanager.com/ns.html?id=GTM-N32P6X"
height="0" width="0" style="display:none;visibility:hidden"&gt;&lt;/iframe&gt;</noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N32P6X');</script>
<!-- End Google Tag Manager -->


<script>
  var current_page = 'news';

  // Globals
  var GLOB = {
        is_sticky : false,
        is_adminbar: false
      },
      $document = $(document),
      $window = $(window),
      $headerTop = $('.header-top');
  
  // Search
  $document.on('mouseenter click', '.searchsubmit', function() {
    // focus on hover and click
    var $this = $(this),
        $input = $this.find('input');
    $this.addClass('active');
    $input.val().trim() === '' && $input.focus();
  })
  .on('mouseleave', '.searchsubmit', function() {
    // remove focus on mouseleave if input is empty
    var $this = $(this);
    $this.find('input').val().trim() === '' && $this.removeClass('active');
  })
  .on('click', '#searchsubmit', function() {
    // prevent from triggering an empty search
    var $form = $(this).closest('form'),
        $input = $form.find('input'),
        value = $input.val().trim();
    if (value === '') {
      $input.focus();
      return false;
    } else {
      $form.submit();
    }
  });

  // Menu
  $document.on('click', '.menu-toggle', function() {
    $('header').toggle('slide');
    $('.menu-toggle .fa-bars').toggle('show');
    $('.menu-toggle .fa-times').toggle('show');
    $('.menu-mobile-center').toggle('show');
    $('.header-logo.mobile').toggle('hide');
  }).on('click', '.menu-all', function() {
    $('.all-head-menu').toggle('slide');
    $('.fa-bars').toggle('show');
    $('.fa-times').toggle('show');
    $('.header-logo.mobile').toggle('show');
  });
  
  // more efficient header scroll
  $window.scroll(function() {
    var $this = $(this),
        scroll = $this.scrollTop(),
        scroll_init = $headerTop.is(':visible') ? $headerTop.height() : 0;

    if (GLOB.is_sticky && scroll > scroll_init) {
      return;
    }
    
    var $header = $('header'),
        $padding = $('.header-padding');

    if (scroll > scroll_init) {
      $header.addClass('sticky');
      $padding.addClass('active');
      GLOB.is_adminbar && $header.addClass('admin');
      GLOB.is_sticky = true;
    } else {
      $header.removeClass('sticky');
      $padding.removeClass('active');
      GLOB.is_sticky = false;
    }
  });
  
  // Ignore # links
  $document.on('click', 'a[href="#"]', function(e) {
    e.preventDefault();
  })
  
  var form_subscribtion = function($form, e, action) {
    var email = $form.find('input').val(),
        emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    
    e.preventDefault();
		document.activeElement.blur();
		$('input').blur();
    console.log(email);

		if(email =='') {
			Dialog.show({ status: 'error', title: 'Subscribe', message: 'Please fill in your email address.' });
		
    } else if(!emailReg.test(email)) {
			Dialog.show({ status: 'error', title: 'Subscribe', message: 'Please enter a valid email address' });
		
    } else {
      console.log(ajaxurl);
      console.log({
				action: action,
				email: email
			});
			$.post(ajaxurl, {
				action: action,
				email: email
			}, function(data) {
        if (typeof data.status !== 'undefined' && data.status === 'success') {
          Dialog.show({ status: 'success', title: 'Subscribe', message: data.message });
        } else if (typeof data.message !== 'undefined') {
          Dialog.show({ status: 'error', title: 'Subscribe', message: data.message });
        } else {
          Dialog.show({ status: 'error', title: 'Subscribe', message: 'There was a problem with the subscribtion request. Please try again.' });
        }
      });
		}
  };

  $document.on('click', '#form-exclusive-updates input[type="button"]', function(e) {
    form_subscribtion($(this).closest('form'), e, 'subscribe_from_home_page_email');
  });
  
  $document.on('click', '#form-signals input[type="button"]', function(e) {
    form_subscribtion($(this).closest('form'), e, 'subscribe_to_signals');
  });
  
  $document.on('click', '.user-profile', function() {
    var $this = $(this),
        $menu = $this.find('.user-menu');
    
    if ($menu.hasClass('active')) {
      $menu.removeClass('active').slideUp();
    } else {
      $menu.addClass('active').slideDown();
    }
  });
  
  // INIT
  $(function(){
    // set adminbar
    GLOB.is_adminbar = $('#wpadminbar').length > 0;
  });
</script>
<input type="hidden" name="term_id" value="47" autocomplete="off">
<input type="hidden" name="page_count" value="4" autocomplete="off">


<script class="">
    var adv1 = '<div id="execphp-45" class="widget widget_execphp">			<div class="execphpwidget"></div>		</div>';
</script>




<div class="main">

 
    <div class="news-categories">
        <div class="container">
            <div class="row">
                <div class="news-categories-item">
                    <div class="circle-cat ">
                        <a href="http://investorz.com/category/industry-news/" class="circle-cat__img"> <i class="icon icon-news1"></i> </a>
                        <span>Industry News</span>
                    </div>
                </div>
                <div class="news-categories-item">
                    <div class="circle-cat active">
                        <a href="http://investorz.com/category/market-news/fundamental-analysis/" class="circle-cat__img"> <i class="icon icon-news2"></i> </a>
                        <span>Fundamental Analysis</span>
                    </div>
                </div>
                <div class="news-categories-item">
                    <div class="circle-cat ">
                        <a href="http://investorz.com/category/market-news/technical-analysis/" class="circle-cat__img"> <i class="icon icon-news3"></i> </a>
                        <span>Technical Analysis</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

            <div class="latest-news">
            <div class="latest-news-titleWrap">
                <div class="latest-news-title">Latest news</div>
            </div>
            <div id="mas_container" style="position: relative; height: 1491px;">
                <div class="grid-sizer"></div>
                                    <div class="news-block-item gridItem" style="position: absolute; left: 0px; top: 0px;">
                        <div class="news-block-img">
                            <a href="http://investorz.com/news/uk-ranks-best-for-digital-business-forex-brokers/">
                                <img src="http://investorz.com/wp-content/uploads/2016/09/UK-ranks-best-for-digital-business.jpg" alt="UK ranks best for digital business: Forex Brokers opportunities"><span class="vfix"></span>
                            </a>
                        </div>
                        <div class="news-block-text">
                            <div class="news-block-type">regulator news</div>
                            <div class="news-block-title"> <a href="http://investorz.com/news/uk-ranks-best-for-digital-business-forex-brokers/">UK ranks best for digital business: Forex Brokers opportunities</a></div>
                        </div>
                        <div class="news-block-botline">
                            <a href="#" class="shareItem">
                                <i class="icon icon-share"></i>
                                <span id="uk-ranks-best-for-digital-business-forex-brokers">0</span>
                                shares                            </a>
                            <script>
                                (function($){
                                    jQuery.sharedCount = function(url, fn) {
                                        //url = encodeURIComponent(url || location.href);
                                        url = "http://investorz.com/news/uk-ranks-best-for-digital-business-forex-brokers/";
                                        var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                        var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                        var arg = {
                                            data: {
                                                url: url,
                                                apikey: apikey
                                            },
                                            url: domain + "/url",
                                            cache: true,
                                            dataType: "json"
                                        };
                                        if ('withCredentials' in new XMLHttpRequest) {
                                            arg.success = fn;
                                        } else {
                                            var cb = "sc_" + url.replace(/\W/g, '');
                                            window[cb] = fn;
                                            arg.jsonpCallback = cb;
                                            arg.dataType += "p";
                                        }
                                        return jQuery.ajax(arg);
                                    };
                                    jQuery.sharedCount(location.href, function(data){
                                        jQuery('#uk-ranks-best-for-digital-business-forex-brokers').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                    });
                                })(jQuery);
                            </script>
                            <div class="dateComItem">
                                <div class="date">9 September 2016</div>
                                <a href="#" class="comments">0</a>
                            </div>
                        </div>
                    </div>
                                                        <div class="news-block-item gridItem" style="position: absolute; left: 437px; top: 0px;">
                        <div class="news-block-img">
                            <a href="http://investorz.com/news/fed-eric-rosengren-supports-gradual-rate-hike/">
                                <img src="http://investorz.com/wp-content/uploads/2014/10/Rosengren-e1473432500320.jpg" alt="Fed Eric Rosengren supports gradual rate hike"><span class="vfix"></span>
                            </a>
                        </div>
                        <div class="news-block-text">
                            <div class="news-block-type">regulator news</div>
                            <div class="news-block-title"> <a href="http://investorz.com/news/fed-eric-rosengren-supports-gradual-rate-hike/">Fed Eric Rosengren supports gradual rate hike</a></div>
                        </div>
                        <div class="news-block-botline">
                            <a href="#" class="shareItem">
                                <i class="icon icon-share"></i>
                                <span id="fed-eric-rosengren-supports-gradual-rate-hike">1</span>
                                shares                            </a>
                            <script>
                                (function($){
                                    jQuery.sharedCount = function(url, fn) {
                                        //url = encodeURIComponent(url || location.href);
                                        url = "http://investorz.com/news/fed-eric-rosengren-supports-gradual-rate-hike/";
                                        var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                        var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                        var arg = {
                                            data: {
                                                url: url,
                                                apikey: apikey
                                            },
                                            url: domain + "/url",
                                            cache: true,
                                            dataType: "json"
                                        };
                                        if ('withCredentials' in new XMLHttpRequest) {
                                            arg.success = fn;
                                        } else {
                                            var cb = "sc_" + url.replace(/\W/g, '');
                                            window[cb] = fn;
                                            arg.jsonpCallback = cb;
                                            arg.dataType += "p";
                                        }
                                        return jQuery.ajax(arg);
                                    };
                                    jQuery.sharedCount(location.href, function(data){
                                        jQuery('#fed-eric-rosengren-supports-gradual-rate-hike').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                    });
                                })(jQuery);
                            </script>
                            <div class="dateComItem">
                                <div class="date">9 September 2016</div>
                                <a href="#" class="comments">0</a>
                            </div>
                        </div>
                    </div>
                                                        <div class="news-block-item gridItem" style="position: absolute; left: 875px; top: 0px;">
                        <div class="news-block-img">
                            <a href="http://investorz.com/news/8-daily-forex-trading-tips-investorz-0909/">
                                <img src="http://investorz.com/wp-content/uploads/2016/07/10-tips.png" alt="8 Daily Forex Trading Tips"><span class="vfix"></span>
                            </a>
                        </div>
                        <div class="news-block-text">
                            <div class="news-block-type">regulator news</div>
                            <div class="news-block-title"> <a href="http://investorz.com/news/8-daily-forex-trading-tips-investorz-0909/">8 Daily Forex Trading Tips</a></div>
                        </div>
                        <div class="news-block-botline">
                            <a href="#" class="shareItem">
                                <i class="icon icon-share"></i>
                                <span id="8-daily-forex-trading-tips-investorz-0909">2</span>
                                shares                            </a>
                            <script>
                                (function($){
                                    jQuery.sharedCount = function(url, fn) {
                                        //url = encodeURIComponent(url || location.href);
                                        url = "http://investorz.com/news/8-daily-forex-trading-tips-investorz-0909/";
                                        var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                        var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                        var arg = {
                                            data: {
                                                url: url,
                                                apikey: apikey
                                            },
                                            url: domain + "/url",
                                            cache: true,
                                            dataType: "json"
                                        };
                                        if ('withCredentials' in new XMLHttpRequest) {
                                            arg.success = fn;
                                        } else {
                                            var cb = "sc_" + url.replace(/\W/g, '');
                                            window[cb] = fn;
                                            arg.jsonpCallback = cb;
                                            arg.dataType += "p";
                                        }
                                        return jQuery.ajax(arg);
                                    };
                                    jQuery.sharedCount(location.href, function(data){
                                        jQuery('#8-daily-forex-trading-tips-investorz-0909').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                    });
                                })(jQuery);
                            </script>
                            <div class="dateComItem">
                                <div class="date">9 September 2016</div>
                                <a href="#" class="comments">0</a>
                            </div>
                        </div>
                    </div>
                                                        <div class="news-block-item gridItem" style="position: absolute; left: 875px; top: 304px;">
                        <div class="news-block-img">
                            <a href="http://investorz.com/news/oil-prices-supported-by-opec-chatter-and-eia-drawdown/">
                                <img src="http://investorz.com/wp-content/uploads/2014/12/Oil-world-e1447682662543.jpg" alt="Oil prices supported by OPEC chatter and EIA drawdown"><span class="vfix"></span>
                            </a>
                        </div>
                        <div class="news-block-text">
                            <div class="news-block-type">regulator news</div>
                            <div class="news-block-title"> <a href="http://investorz.com/news/oil-prices-supported-by-opec-chatter-and-eia-drawdown/">Oil prices supported by OPEC chatter and EIA drawdown</a></div>
                        </div>
                        <div class="news-block-botline">
                            <a href="#" class="shareItem">
                                <i class="icon icon-share"></i>
                                <span id="oil-prices-supported-by-opec-chatter-and-eia-drawdown">1</span>
                                shares                            </a>
                            <script>
                                (function($){
                                    jQuery.sharedCount = function(url, fn) {
                                        //url = encodeURIComponent(url || location.href);
                                        url = "http://investorz.com/news/oil-prices-supported-by-opec-chatter-and-eia-drawdown/";
                                        var domain = "//free.sharedcount.com"; /* SET DOMAIN */
                                        var apikey = "fc746156cc6bb54debfaf7d42a9332db5f13b2b8" /*API KEY HERE*/
                                        var arg = {
                                            data: {
                                                url: url,
                                                apikey: apikey
                                            },
                                            url: domain + "/url",
                                            cache: true,
                                            dataType: "json"
                                        };
                                        if ('withCredentials' in new XMLHttpRequest) {
                                            arg.success = fn;
                                        } else {
                                            var cb = "sc_" + url.replace(/\W/g, '');
                                            window[cb] = fn;
                                            arg.jsonpCallback = cb;
                                            arg.dataType += "p";
                                        }
                                        return jQuery.ajax(arg);
                                    };
                                    jQuery.sharedCount(location.href, function(data){
                                        jQuery('#oil-prices-supported-by-opec-chatter-and-eia-drawdown').text(data.Twitter + data.Facebook.total_count + data.GooglePlusOne + data.Pinterest + data.LinkedIn);
                                    });
                                })(jQuery);
                            </script>
                            <div class="dateComItem">
                                <div class="date">9 September 2016</div>
                                <a href="#" class="comments">0</a>
                            </div>
                        </div>
                    </div>


<!--                ----------- Neeraj ---------------------->









                <div class="news-block-item gridItem" style="position: absolute; left: 875px; top: 304px;">
                    <div class="news-block-img">
                       Image 4
                    </div>
                    <div class="news-block-text">

                       Block4
                         </div>
                    <div class="news-block-botline">
                       Bottom Line 4
                </div>




                    <div class="news-block-item gridItem" style="position: absolute; left: 875px; top: 304px;">
                        <div class="news-block-img">
                            Image 5
                        </div>
                        <div class="news-block-text">

                            Block5
                        </div>
                        <div class="news-block-botline">
                            Bottom Line 5
                        </div>



                                    
            </div>
        </div>
    
</div>
</div>  
<?php get_footer(); ?> 