<?php /* Template Name: Institutional FX */ ?>

<?php get_header(); ?>
<div class="container"></div>
<?php get_footer(); ?>