<?php /* Template Name: Binary Trading */ ?>

<?php get_header(); ?>
<div class="container">
</div>
<?php get_footer(); ?>

