<?php /* Template Name: Beginner's Guide */ ?>
<?php get_header(); ?>
<div class="container">
</div>
<?php get_footer(); ?>