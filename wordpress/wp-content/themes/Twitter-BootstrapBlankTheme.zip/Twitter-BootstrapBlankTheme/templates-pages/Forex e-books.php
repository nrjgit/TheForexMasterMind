<?php /* Template Name: Forex e-books */ ?>

<?php get_header(); ?>
<div class="container">

<div class="main ebook-page">

    <div class="jumbotron jumbotron18" style="background-image: url('http://atozforex.com/wp-content/uploads/2015/09/jumbotron18.jpg');">
        <div class="container">
            <div class="jumbotron-block pull-right">
                <div class="jumbotron-block__title"><a href="#">Forex ebooks</a></div>
                AtoZ <a href="#">Forex ebooks</a> drive from the famous quote "<em>An investment in knowledge always pays the best interest.</em>"

Download your Forex eBook now!                <a href="#" class="btn btn-danger btn-xl move-down">GET STARTED</a>
            </div>
            <a href="#" class="go-down"><i class="icon-sprite icon-circle-arrow-down-w"></i></a>
        </div>
    </div>

        <div class="ebookCat">
        <div class="ebookCat-bg">
            <div class="container">
                <div class="ebookCat-row">
                                            <div class="column">
                            <div class="ebookCat-item">
                                <a href="http://atozforex.com/ebooks/?category=for-beginners"><i class="icon icon-ebook-img01"></i></a>
                                <span>For Beginners</span>
                            </div>
                        </div>
                                            <div class="column">
                            <div class="ebookCat-item">
                                <a href="http://atozforex.com/ebooks/?category=forex-market-in-general"><i class="icon icon-ebook-img02"></i></a>
                                <span>Forex Market in General</span>
                            </div>
                        </div>
                                            <div class="column">
                            <div class="ebookCat-item">
                                <a href="http://atozforex.com/ebooks/?category=psychology-of-trading"><i class="icon icon-ebook-img03"></i></a>
                                <span>Psychology of Trading</span>
                            </div>
                        </div>
                                            <div class="column">
                            <div class="ebookCat-item">
                                <a href="http://atozforex.com/ebooks/?category=money-management"><i class="icon icon-ebook-img04"></i></a>
                                <span>Money Management</span>
                            </div>
                        </div>
                                            <div class="column">
                            <div class="ebookCat-item">
                                <a href="http://atozforex.com/ebooks/?category=forex-strategy"><i class="icon icon-ebook-img05"></i></a>
                                <span>Forex Strategy</span>
                            </div>
                        </div>
                                            <div class="column">
                            <div class="ebookCat-item">
                                <a href="http://atozforex.com/ebooks/?category=advanced-forex-trading"><i class="icon icon-ebook-img06"></i></a>
                                <span>Advanced Forex Trading</span>
                            </div>
                        </div>
                                    </div>
            </div>
        </div>
    </div>
    
    <div class="container">
                <div class="ebookCatalog">
            <div class="ebookCatalog-row">

                                                    <div class="column">
                        <div class="ebookCatalog-item">
                                                            <a href="#loginForm" class="fancybox-popup">
                                                                                        <div class="icon icon-itemNew"></div>
                                                            <div class="ebookCatalog-item-header">
                                    <img src="http://atozforex.com/wp-content/uploads/2015/10/Insiders-Guide-to-Successful-Trading2-302x215.jpg" alt="Insider’s Guide to Suc...">
                                </div>
                                <div class="ebookCatalog-item-footer">
                                    <div class="ebookCatalog-item-footer-title">
                                        For Beginners, Forex Market in General, Psy...                                    </div>
                                    <div class="ebookCatalog-item-footer-aftor">
                                        <span>Insider’s Guide to Suc...</span>
                                        From basic concepts like margi...                                    </div>
                                    <div class="published">
                                        PUBLISHED Oct 10, 2015                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                                                        <div class="column">
                        <div class="ebookCatalog-item">
                                                            <a href="#loginForm" class="fancybox-popup">
                                                                                        <div class="icon icon-itemNew"></div>
                                                            <div class="ebookCatalog-item-header">
                                    <img src="http://atozforex.com/wp-content/uploads/2015/10/A-Guide-To-Strategic-Forex-Trading1-302x231.png" alt="A Guide to Strategic For...">
                                </div>
                                <div class="ebookCatalog-item-footer">
                                    <div class="ebookCatalog-item-footer-title">
                                        For Beginners, Forex Strategy, Psychology o...                                    </div>
                                    <div class="ebookCatalog-item-footer-aftor">
                                        <span>A Guide to Strategic For...</span>
                                        Trading currencies does not ha...                                    </div>
                                    <div class="published">
                                        PUBLISHED Oct 10, 2015                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                                                        <div class="column">
                        <div class="ebookCatalog-item">
                                                            <a href="#loginForm" class="fancybox-popup">
                                                                                        <div class="icon icon-itemNew"></div>
                                                            <div class="ebookCatalog-item-header">
                                    <img src="http://atozforex.com/wp-content/uploads/2015/10/Using-candlesticks-Orbex1-302x211.png" alt="Using Candlestick Charts...">
                                </div>
                                <div class="ebookCatalog-item-footer">
                                    <div class="ebookCatalog-item-footer-title">
                                        For Beginners, Forex Market in General, For...                                    </div>
                                    <div class="ebookCatalog-item-footer-aftor">
                                        <span>Using Candlestick Charts...</span>
                                        If you’re just getting into ...                                    </div>
                                    <div class="published">
                                        PUBLISHED Oct 10, 2015                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                                            <div class="horizontalBaner">
                            <div id="execphp-30" class="widget widget_execphp">			<div class="execphpwidget"><a href="http://www.ads-securities.co.uk/secure-broker/?utm_source=cpm&amp;utm_medium=broker-profile&amp;utm_campaign=2015-q4-atozforex&amp;cmp=atozforex" target="_Top"><img border="0" src="/wp-content/uploads/2016/05/ADS-Securities-London-AtoZForex-Approved-728-90.jpg"></a></div>		</div>                        </div>
                                                        <div class="column">
                        <div class="ebookCatalog-item">
                                                            <a href="#loginForm" class="fancybox-popup">
                                                                                        <div class="ebookCatalog-item-header">
                                    <img src="http://atozforex.com/wp-content/uploads/2015/11/Turtle-Trading-Rules-302x452.png" alt="The Original Turtle Trad...">
                                </div>
                                <div class="ebookCatalog-item-footer">
                                    <div class="ebookCatalog-item-footer-title">
                                        Advanced Forex Trading, Forex Market in Gen...                                    </div>
                                    <div class="ebookCatalog-item-footer-aftor">
                                        <span>The Original Turtle Trad...</span>
                                        The Original Turtle Trading ru...                                    </div>
                                    <div class="published">
                                        PUBLISHED Sep 9, 2015                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                                                        <div class="column">
                        <div class="ebookCatalog-item">
                                                            <a href="#loginForm" class="fancybox-popup">
                                                                                        <div class="ebookCatalog-item-header">
                                    <img src="http://atozforex.com/wp-content/uploads/2015/11/the-artful-trader-302x453.png" alt="The Artful Trader">
                                </div>
                                <div class="ebookCatalog-item-footer">
                                    <div class="ebookCatalog-item-footer-title">
                                        For Beginners, Psychology of Trading                                    </div>
                                    <div class="ebookCatalog-item-footer-aftor">
                                        <span>The Artful Trader</span>
                                        Written by Selwyn Michael Gish...                                    </div>
                                    <div class="published">
                                        PUBLISHED Sep 9, 2015                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                                                        <div class="column">
                        <div class="ebookCatalog-item">
                                                            <a href="#loginForm" class="fancybox-popup">
                                                                                        <div class="ebookCatalog-item-header">
                                    <img src="http://atozforex.com/wp-content/uploads/2015/09/NYSE-Book-302x453.png" alt="The NYSE Tick Index and ...">
                                </div>
                                <div class="ebookCatalog-item-footer">
                                    <div class="ebookCatalog-item-footer-title">
                                        For Beginners, Psychology of Trading                                    </div>
                                    <div class="ebookCatalog-item-footer-aftor">
                                        <span>The NYSE Tick Index and ...</span>
                                        NYSE Tick Index and Candlestic...                                    </div>
                                    <div class="published">
                                        PUBLISHED Sep 9, 2015                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                                            <div class="horizontalBaner">
                                                    </div>
                                                </div>
        </div>
            </div>

    <div id="f-trigger"></div>

</div>


</div>
<?php get_footer(); ?>

