<?php /* Template Name: Trading System */ ?>

<?php get_header(); ?>
<div class="container"></div>
<?php get_footer(); ?>

