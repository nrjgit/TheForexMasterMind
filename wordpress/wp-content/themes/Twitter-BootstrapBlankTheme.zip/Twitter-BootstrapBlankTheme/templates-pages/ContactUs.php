<?php /* Template Name: Contact Us */ ?>

<?php get_header(); ?>
<div class="container">

<div class="main contacts-page">
    <div class="jumbotron jumbotron09" style="background-image: url('http://atozforex.com/verstka/images/jumbotron09.jpg');">
        <div class="container">
            <div class="jumbotron-block pull-right">
                <div class="jumbotron-block__title">Get In Touch</div>
                <div class="white-form zNice zForm">
                    <form method="post" action="" name="contact-us" id="contact-us" novalidate="novalidate">
                        <div class="form-row">
                            <div class="form-col">
                                <span class="zNice-wrap whiteInput zNice-tInput"><span class="zNice-bg"></span><input type="text" name="full_name" id="full_name" placeholder="Your Name*" class=""></span>
                            </div>
                            <div class="form-col">
                                <span class="zNice-wrap whiteInput zNice-tInput"><span class="zNice-bg"></span><input type="email" name="email" id="email" placeholder="yoremail@gmail.com*" class="" required="required"></span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-col">
                                <span class="zNice-wrap whiteInput zNice-tInput"><span class="zNice-bg"></span><input type="text" name="phone_number" id="phone_number" placeholder="Phone Number*" class=""></span>
                            </div>
                            <div class="form-col">
                                <span class="zNice-wrap zNice-select"><span class="zNice-bg"></span><select name="country" id="country">
                                    <option value="">Country*</option>
                                    <option value="Afganistan">Afghanistan</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
                                    <option value="Argentina">Argentina</option>
                                    <option value="Armenia">Armenia</option>
                                    <option value="Aruba">Aruba</option>
                                    <option value="Australia">Australia</option>
                                    <option value="Austria">Austria</option>
                                    <option value="Azerbaijan">Azerbaijan</option>
                                    <option value="Bahamas">Bahamas</option>
                                    <option value="Bahrain">Bahrain</option>
                                    <option value="Bangladesh">Bangladesh</option>
                                    <option value="Barbados">Barbados</option>
                                    <option value="Belarus">Belarus</option>
                                    <option value="Belgium">Belgium</option>
                                    <option value="Belize">Belize</option>
                                    <option value="Benin">Benin</option>
                                    <option value="Bermuda">Bermuda</option>
                                    <option value="Bhutan">Bhutan</option>
                                    <option value="Bolivia">Bolivia</option>
                                    <option value="Bonaire">Bonaire</option>
                                    <option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option>
                                    <option value="Botswana">Botswana</option>
                                    <option value="Brazil">Brazil</option>
                                    <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                                    <option value="Brunei">Brunei</option>
                                    <option value="Bulgaria">Bulgaria</option>
                                    <option value="Burkina Faso">Burkina Faso</option>
                                    <option value="Burundi">Burundi</option>
                                    <option value="Cambodia">Cambodia</option>
                                    <option value="Cameroon">Cameroon</option>
                                    <option value="Canada">Canada</option>
                                    <option value="Canary Islands">Canary Islands</option>
                                    <option value="Cape Verde">Cape Verde</option>
                                    <option value="Cayman Islands">Cayman Islands</option>
                                    <option value="Central African Republic">Central African Republic</option>
                                    <option value="Chad">Chad</option>
                                    <option value="Channel Islands">Channel Islands</option>
                                    <option value="Chile">Chile</option>
                                    <option value="China">China</option>
                                    <option value="Christmas Island">Christmas Island</option>
                                    <option value="Cocos Island">Cocos Island</option>
                                    <option value="Colombia">Colombia</option>
                                    <option value="Comoros">Comoros</option>
                                    <option value="Congo">Congo</option>
                                    <option value="Cook Islands">Cook Islands</option>
                                    <option value="Costa Rica">Costa Rica</option>
                                    <option value="Cote DIvoire">Cote D'Ivoire</option>
                                    <option value="Croatia">Croatia</option>
                                    <option value="Cuba">Cuba</option>
                                    <option value="Curaco">Curacao</option>
                                    <option value="Cyprus">Cyprus</option>
                                    <option value="Czech Republic">Czech Republic</option>
                                    <option value="Denmark">Denmark</option>
                                    <option value="Djibouti">Djibouti</option>
                                    <option value="Dominica">Dominica</option>
                                    <option value="Dominican Republic">Dominican Republic</option>
                                    <option value="East Timor">East Timor</option>
                                    <option value="Ecuador">Ecuador</option>
                                    <option value="Egypt">Egypt</option>
                                    <option value="El Salvador">El Salvador</option>
                                    <option value="Equatorial Guinea">Equatorial Guinea</option>
                                    <option value="Eritrea">Eritrea</option>
                                    <option value="Estonia">Estonia</option>
                                    <option value="Ethiopia">Ethiopia</option>
                                    <option value="Falkland Islands">Falkland Islands</option>
                                    <option value="Faroe Islands">Faroe Islands</option>
                                    <option value="Fiji">Fiji</option>
                                    <option value="Finland">Finland</option>
                                    <option value="France">France</option>
                                    <option value="French Guiana">French Guiana</option>
                                    <option value="French Polynesia">French Polynesia</option>
                                    <option value="French Southern Ter">French Southern Ter</option>
                                    <option value="Gabon">Gabon</option>
                                    <option value="Gambia">Gambia</option>
                                    <option value="Georgia">Georgia</option>
                                    <option value="Germany">Germany</option>
                                    <option value="Ghana">Ghana</option>
                                    <option value="Gibraltar">Gibraltar</option>
                                    <option value="Great Britain">Great Britain</option>
                                    <option value="Greece">Greece</option>
                                    <option value="Greenland">Greenland</option>
                                    <option value="Grenada">Grenada</option>
                                    <option value="Guadeloupe">Guadeloupe</option>
                                    <option value="Guam">Guam</option>
                                    <option value="Guatemala">Guatemala</option>
                                    <option value="Guinea">Guinea</option>
                                    <option value="Guyana">Guyana</option>
                                    <option value="Haiti">Haiti</option>
                                    <option value="Hawaii">Hawaii</option>
                                    <option value="Honduras">Honduras</option>
                                    <option value="Hong Kong">Hong Kong</option>
                                    <option value="Hungary">Hungary</option>
                                    <option value="Iceland">Iceland</option>
                                    <option value="India">India</option>
                                    <option value="Indonesia">Indonesia</option>
                                    <option value="Iran">Iran</option>
                                    <option value="Iraq">Iraq</option>
                                    <option value="Ireland">Ireland</option>
                                    <option value="Isle of Man">Isle of Man</option>
                                    <option value="Israel">Israel</option>
                                    <option value="Italy">Italy</option>
                                    <option value="Jamaica">Jamaica</option>
                                    <option value="Japan">Japan</option>
                                    <option value="Jordan">Jordan</option>
                                    <option value="Kazakhstan">Kazakhstan</option>
                                    <option value="Kenya">Kenya</option>
                                    <option value="Kiribati">Kiribati</option>
                                    <option value="Korea North">Korea North</option>
                                    <option value="Korea Sout">Korea South</option>
                                    <option value="Kuwait">Kuwait</option>
                                    <option value="Kyrgyzstan">Kyrgyzstan</option>
                                    <option value="Laos">Laos</option>
                                    <option value="Latvia">Latvia</option>
                                    <option value="Lebanon">Lebanon</option>
                                    <option value="Lesotho">Lesotho</option>
                                    <option value="Liberia">Liberia</option>
                                    <option value="Libya">Libya</option>
                                    <option value="Liechtenstein">Liechtenstein</option>
                                    <option value="Lithuania">Lithuania</option>
                                    <option value="Luxembourg">Luxembourg</option>
                                    <option value="Macau">Macau</option>
                                    <option value="Macedonia">Macedonia</option>
                                    <option value="Madagascar">Madagascar</option>
                                    <option value="Malaysia">Malaysia</option>
                                    <option value="Malawi">Malawi</option>
                                    <option value="Maldives">Maldives</option>
                                    <option value="Mali">Mali</option>
                                    <option value="Malta">Malta</option>
                                    <option value="Marshall Islands">Marshall Islands</option>
                                    <option value="Martinique">Martinique</option>
                                    <option value="Mauritania">Mauritania</option>
                                    <option value="Mauritius">Mauritius</option>
                                    <option value="Mayotte">Mayotte</option>
                                    <option value="Mexico">Mexico</option>
                                    <option value="Midway Islands">Midway Islands</option>
                                    <option value="Moldova">Moldova</option>
                                    <option value="Monaco">Monaco</option>
                                    <option value="Mongolia">Mongolia</option>
                                    <option value="Montserrat">Montserrat</option>
                                    <option value="Morocco">Morocco</option>
                                    <option value="Mozambique">Mozambique</option>
                                    <option value="Myanmar">Myanmar</option>
                                    <option value="Nambia">Nambia</option>
                                    <option value="Nauru">Nauru</option>
                                    <option value="Nepal">Nepal</option>
                                    <option value="Netherland Antilles">Netherland Antilles</option>
                                    <option value="Netherlands">Netherlands (Holland, Europe)</option>
                                    <option value="Nevis">Nevis</option>
                                    <option value="New Caledonia">New Caledonia</option>
                                    <option value="New Zealand">New Zealand</option>
                                    <option value="Nicaragua">Nicaragua</option>
                                    <option value="Niger">Niger</option>
                                    <option value="Nigeria">Nigeria</option>
                                    <option value="Niue">Niue</option>
                                    <option value="Norfolk Island">Norfolk Island</option>
                                    <option value="Norway">Norway</option>
                                    <option value="Oman">Oman</option>
                                    <option value="Pakistan">Pakistan</option>
                                    <option value="Palau Island">Palau Island</option>
                                    <option value="Palestine">Palestine</option>
                                    <option value="Panama">Panama</option>
                                    <option value="Papua New Guinea">Papua New Guinea</option>
                                    <option value="Paraguay">Paraguay</option>
                                    <option value="Peru">Peru</option>
                                    <option value="Phillipines">Philippines</option>
                                    <option value="Pitcairn Island">Pitcairn Island</option>
                                    <option value="Poland">Poland</option>
                                    <option value="Portugal">Portugal</option>
                                    <option value="Puerto Rico">Puerto Rico</option>
                                    <option value="Qatar">Qatar</option>
                                    <option value="Republic of Montenegro">Republic of Montenegro</option>
                                    <option value="Republic of Serbia">Republic of Serbia</option>
                                    <option value="Reunion">Reunion</option>
                                    <option value="Romania">Romania</option>
                                    <option value="Russia">Russia</option>
                                    <option value="Rwanda">Rwanda</option>
                                    <option value="St Barthelemy">St Barthelemy</option>
                                    <option value="St Eustatius">St Eustatius</option>
                                    <option value="St Helena">St Helena</option>
                                    <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                                    <option value="St Lucia">St Lucia</option>
                                    <option value="St Maarten">St Maarten</option>
                                    <option value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon</option>
                                    <option value="St Vincent &amp; Grenadines">St Vincent &amp; Grenadines</option>
                                    <option value="Saipan">Saipan</option>
                                    <option value="Samoa">Samoa</option>
                                    <option value="Samoa American">Samoa American</option>
                                    <option value="San Marino">San Marino</option>
                                    <option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option>
                                    <option value="Saudi Arabia">Saudi Arabia</option>
                                    <option value="Senegal">Senegal</option>
                                    <option value="Serbia">Serbia</option>
                                    <option value="Seychelles">Seychelles</option>
                                    <option value="Sierra Leone">Sierra Leone</option>
                                    <option value="Singapore">Singapore</option>
                                    <option value="Slovakia">Slovakia</option>
                                    <option value="Slovenia">Slovenia</option>
                                    <option value="Solomon Islands">Solomon Islands</option>
                                    <option value="Somalia">Somalia</option>
                                    <option value="South Africa">South Africa</option>
                                    <option value="Spain">Spain</option>
                                    <option value="Sri Lanka">Sri Lanka</option>
                                    <option value="Sudan">Sudan</option>
                                    <option value="Suriname">Suriname</option>
                                    <option value="Swaziland">Swaziland</option>
                                    <option value="Sweden">Sweden</option>
                                    <option value="Switzerland">Switzerland</option>
                                    <option value="Syria">Syria</option>
                                    <option value="Tahiti">Tahiti</option>
                                    <option value="Taiwan">Taiwan</option>
                                    <option value="Tajikistan">Tajikistan</option>
                                    <option value="Tanzania">Tanzania</option>
                                    <option value="Thailand">Thailand</option>
                                    <option value="Togo">Togo</option>
                                    <option value="Tokelau">Tokelau</option>
                                    <option value="Tonga">Tonga</option>
                                    <option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
                                    <option value="Tunisia">Tunisia</option>
                                    <option value="Turkey">Turkey</option>
                                    <option value="Turkmenistan">Turkmenistan</option>
                                    <option value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
                                    <option value="Tuvalu">Tuvalu</option>
                                    <option value="Uganda">Uganda</option>
                                    <option value="Ukraine">Ukraine</option>
                                    <option value="United Arab Erimates">United Arab Emirates</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="United States of America">United States of America</option>
                                    <option value="Uraguay">Uruguay</option>
                                    <option value="Uzbekistan">Uzbekistan</option>
                                    <option value="Vanuatu">Vanuatu</option>
                                    <option value="Vatican City State">Vatican City State</option>
                                    <option value="Venezuela">Venezuela</option>
                                    <option value="Vietnam">Vietnam</option>
                                    <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                                    <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                                    <option value="Wake Island">Wake Island</option>
                                    <option value="Wallis &amp; Futana Is">Wallis &amp; Futana Is</option>
                                    <option value="Yemen">Yemen</option>
                                    <option value="Zaire">Zaire</option>
                                    <option value="Zambia">Zambia</option>
                                    <option value="Zimbabwe">Zimbabwe</option>
                                </select><span class="zNice-select-text"><span class="zNice-select-item">Country*</span></span><span class="zNice-select-open"></span><ul class="zNice-select-list"><li class="zNice-selected"><span class="zNice-select-item">Country*</span></li><li><span class="zNice-select-item">Afghanistan</span></li><li><span class="zNice-select-item">Albania</span></li><li><span class="zNice-select-item">Algeria</span></li><li><span class="zNice-select-item">American Samoa</span></li><li><span class="zNice-select-item">Andorra</span></li><li><span class="zNice-select-item">Angola</span></li><li><span class="zNice-select-item">Anguilla</span></li><li><span class="zNice-select-item">Antigua &amp; Barbuda</span></li><li><span class="zNice-select-item">Argentina</span></li><li><span class="zNice-select-item">Armenia</span></li><li><span class="zNice-select-item">Aruba</span></li><li><span class="zNice-select-item">Australia</span></li><li><span class="zNice-select-item">Austria</span></li><li><span class="zNice-select-item">Azerbaijan</span></li><li><span class="zNice-select-item">Bahamas</span></li><li><span class="zNice-select-item">Bahrain</span></li><li><span class="zNice-select-item">Bangladesh</span></li><li><span class="zNice-select-item">Barbados</span></li><li><span class="zNice-select-item">Belarus</span></li><li><span class="zNice-select-item">Belgium</span></li><li><span class="zNice-select-item">Belize</span></li><li><span class="zNice-select-item">Benin</span></li><li><span class="zNice-select-item">Bermuda</span></li><li><span class="zNice-select-item">Bhutan</span></li><li><span class="zNice-select-item">Bolivia</span></li><li><span class="zNice-select-item">Bonaire</span></li><li><span class="zNice-select-item">Bosnia &amp; Herzegovina</span></li><li><span class="zNice-select-item">Botswana</span></li><li><span class="zNice-select-item">Brazil</span></li><li><span class="zNice-select-item">British Indian Ocean Ter</span></li><li><span class="zNice-select-item">Brunei</span></li><li><span class="zNice-select-item">Bulgaria</span></li><li><span class="zNice-select-item">Burkina Faso</span></li><li><span class="zNice-select-item">Burundi</span></li><li><span class="zNice-select-item">Cambodia</span></li><li><span class="zNice-select-item">Cameroon</span></li><li><span class="zNice-select-item">Canada</span></li><li><span class="zNice-select-item">Canary Islands</span></li><li><span class="zNice-select-item">Cape Verde</span></li><li><span class="zNice-select-item">Cayman Islands</span></li><li><span class="zNice-select-item">Central African Republic</span></li><li><span class="zNice-select-item">Chad</span></li><li><span class="zNice-select-item">Channel Islands</span></li><li><span class="zNice-select-item">Chile</span></li><li><span class="zNice-select-item">China</span></li><li><span class="zNice-select-item">Christmas Island</span></li><li><span class="zNice-select-item">Cocos Island</span></li><li><span class="zNice-select-item">Colombia</span></li><li><span class="zNice-select-item">Comoros</span></li><li><span class="zNice-select-item">Congo</span></li><li><span class="zNice-select-item">Cook Islands</span></li><li><span class="zNice-select-item">Costa Rica</span></li><li><span class="zNice-select-item">Cote D'Ivoire</span></li><li><span class="zNice-select-item">Croatia</span></li><li><span class="zNice-select-item">Cuba</span></li><li><span class="zNice-select-item">Curacao</span></li><li><span class="zNice-select-item">Cyprus</span></li><li><span class="zNice-select-item">Czech Republic</span></li><li><span class="zNice-select-item">Denmark</span></li><li><span class="zNice-select-item">Djibouti</span></li><li><span class="zNice-select-item">Dominica</span></li><li><span class="zNice-select-item">Dominican Republic</span></li><li><span class="zNice-select-item">East Timor</span></li><li><span class="zNice-select-item">Ecuador</span></li><li><span class="zNice-select-item">Egypt</span></li><li><span class="zNice-select-item">El Salvador</span></li><li><span class="zNice-select-item">Equatorial Guinea</span></li><li><span class="zNice-select-item">Eritrea</span></li><li><span class="zNice-select-item">Estonia</span></li><li><span class="zNice-select-item">Ethiopia</span></li><li><span class="zNice-select-item">Falkland Islands</span></li><li><span class="zNice-select-item">Faroe Islands</span></li><li><span class="zNice-select-item">Fiji</span></li><li><span class="zNice-select-item">Finland</span></li><li><span class="zNice-select-item">France</span></li><li><span class="zNice-select-item">French Guiana</span></li><li><span class="zNice-select-item">French Polynesia</span></li><li><span class="zNice-select-item">French Southern Ter</span></li><li><span class="zNice-select-item">Gabon</span></li><li><span class="zNice-select-item">Gambia</span></li><li><span class="zNice-select-item">Georgia</span></li><li><span class="zNice-select-item">Germany</span></li><li><span class="zNice-select-item">Ghana</span></li><li><span class="zNice-select-item">Gibraltar</span></li><li><span class="zNice-select-item">Great Britain</span></li><li><span class="zNice-select-item">Greece</span></li><li><span class="zNice-select-item">Greenland</span></li><li><span class="zNice-select-item">Grenada</span></li><li><span class="zNice-select-item">Guadeloupe</span></li><li><span class="zNice-select-item">Guam</span></li><li><span class="zNice-select-item">Guatemala</span></li><li><span class="zNice-select-item">Guinea</span></li><li><span class="zNice-select-item">Guyana</span></li><li><span class="zNice-select-item">Haiti</span></li><li><span class="zNice-select-item">Hawaii</span></li><li><span class="zNice-select-item">Honduras</span></li><li><span class="zNice-select-item">Hong Kong</span></li><li><span class="zNice-select-item">Hungary</span></li><li><span class="zNice-select-item">Iceland</span></li><li><span class="zNice-select-item">India</span></li><li><span class="zNice-select-item">Indonesia</span></li><li><span class="zNice-select-item">Iran</span></li><li><span class="zNice-select-item">Iraq</span></li><li><span class="zNice-select-item">Ireland</span></li><li><span class="zNice-select-item">Isle of Man</span></li><li><span class="zNice-select-item">Israel</span></li><li><span class="zNice-select-item">Italy</span></li><li><span class="zNice-select-item">Jamaica</span></li><li><span class="zNice-select-item">Japan</span></li><li><span class="zNice-select-item">Jordan</span></li><li><span class="zNice-select-item">Kazakhstan</span></li><li><span class="zNice-select-item">Kenya</span></li><li><span class="zNice-select-item">Kiribati</span></li><li><span class="zNice-select-item">Korea North</span></li><li><span class="zNice-select-item">Korea South</span></li><li><span class="zNice-select-item">Kuwait</span></li><li><span class="zNice-select-item">Kyrgyzstan</span></li><li><span class="zNice-select-item">Laos</span></li><li><span class="zNice-select-item">Latvia</span></li><li><span class="zNice-select-item">Lebanon</span></li><li><span class="zNice-select-item">Lesotho</span></li><li><span class="zNice-select-item">Liberia</span></li><li><span class="zNice-select-item">Libya</span></li><li><span class="zNice-select-item">Liechtenstein</span></li><li><span class="zNice-select-item">Lithuania</span></li><li><span class="zNice-select-item">Luxembourg</span></li><li><span class="zNice-select-item">Macau</span></li><li><span class="zNice-select-item">Macedonia</span></li><li><span class="zNice-select-item">Madagascar</span></li><li><span class="zNice-select-item">Malaysia</span></li><li><span class="zNice-select-item">Malawi</span></li><li><span class="zNice-select-item">Maldives</span></li><li><span class="zNice-select-item">Mali</span></li><li><span class="zNice-select-item">Malta</span></li><li><span class="zNice-select-item">Marshall Islands</span></li><li><span class="zNice-select-item">Martinique</span></li><li><span class="zNice-select-item">Mauritania</span></li><li><span class="zNice-select-item">Mauritius</span></li><li><span class="zNice-select-item">Mayotte</span></li><li><span class="zNice-select-item">Mexico</span></li><li><span class="zNice-select-item">Midway Islands</span></li><li><span class="zNice-select-item">Moldova</span></li><li><span class="zNice-select-item">Monaco</span></li><li><span class="zNice-select-item">Mongolia</span></li><li><span class="zNice-select-item">Montserrat</span></li><li><span class="zNice-select-item">Morocco</span></li><li><span class="zNice-select-item">Mozambique</span></li><li><span class="zNice-select-item">Myanmar</span></li><li><span class="zNice-select-item">Nambia</span></li><li><span class="zNice-select-item">Nauru</span></li><li><span class="zNice-select-item">Nepal</span></li><li><span class="zNice-select-item">Netherland Antilles</span></li><li><span class="zNice-select-item">Netherlands (Holland, Europe)</span></li><li><span class="zNice-select-item">Nevis</span></li><li><span class="zNice-select-item">New Caledonia</span></li><li><span class="zNice-select-item">New Zealand</span></li><li><span class="zNice-select-item">Nicaragua</span></li><li><span class="zNice-select-item">Niger</span></li><li><span class="zNice-select-item">Nigeria</span></li><li><span class="zNice-select-item">Niue</span></li><li><span class="zNice-select-item">Norfolk Island</span></li><li><span class="zNice-select-item">Norway</span></li><li><span class="zNice-select-item">Oman</span></li><li><span class="zNice-select-item">Pakistan</span></li><li><span class="zNice-select-item">Palau Island</span></li><li><span class="zNice-select-item">Palestine</span></li><li><span class="zNice-select-item">Panama</span></li><li><span class="zNice-select-item">Papua New Guinea</span></li><li><span class="zNice-select-item">Paraguay</span></li><li><span class="zNice-select-item">Peru</span></li><li><span class="zNice-select-item">Philippines</span></li><li><span class="zNice-select-item">Pitcairn Island</span></li><li><span class="zNice-select-item">Poland</span></li><li><span class="zNice-select-item">Portugal</span></li><li><span class="zNice-select-item">Puerto Rico</span></li><li><span class="zNice-select-item">Qatar</span></li><li><span class="zNice-select-item">Republic of Montenegro</span></li><li><span class="zNice-select-item">Republic of Serbia</span></li><li><span class="zNice-select-item">Reunion</span></li><li><span class="zNice-select-item">Romania</span></li><li><span class="zNice-select-item">Russia</span></li><li><span class="zNice-select-item">Rwanda</span></li><li><span class="zNice-select-item">St Barthelemy</span></li><li><span class="zNice-select-item">St Eustatius</span></li><li><span class="zNice-select-item">St Helena</span></li><li><span class="zNice-select-item">St Kitts-Nevis</span></li><li><span class="zNice-select-item">St Lucia</span></li><li><span class="zNice-select-item">St Maarten</span></li><li><span class="zNice-select-item">St Pierre &amp; Miquelon</span></li><li><span class="zNice-select-item">St Vincent &amp; Grenadines</span></li><li><span class="zNice-select-item">Saipan</span></li><li><span class="zNice-select-item">Samoa</span></li><li><span class="zNice-select-item">Samoa American</span></li><li><span class="zNice-select-item">San Marino</span></li><li><span class="zNice-select-item">Sao Tome &amp; Principe</span></li><li><span class="zNice-select-item">Saudi Arabia</span></li><li><span class="zNice-select-item">Senegal</span></li><li><span class="zNice-select-item">Serbia</span></li><li><span class="zNice-select-item">Seychelles</span></li><li><span class="zNice-select-item">Sierra Leone</span></li><li><span class="zNice-select-item">Singapore</span></li><li><span class="zNice-select-item">Slovakia</span></li><li><span class="zNice-select-item">Slovenia</span></li><li><span class="zNice-select-item">Solomon Islands</span></li><li><span class="zNice-select-item">Somalia</span></li><li><span class="zNice-select-item">South Africa</span></li><li><span class="zNice-select-item">Spain</span></li><li><span class="zNice-select-item">Sri Lanka</span></li><li><span class="zNice-select-item">Sudan</span></li><li><span class="zNice-select-item">Suriname</span></li><li><span class="zNice-select-item">Swaziland</span></li><li><span class="zNice-select-item">Sweden</span></li><li><span class="zNice-select-item">Switzerland</span></li><li><span class="zNice-select-item">Syria</span></li><li><span class="zNice-select-item">Tahiti</span></li><li><span class="zNice-select-item">Taiwan</span></li><li><span class="zNice-select-item">Tajikistan</span></li><li><span class="zNice-select-item">Tanzania</span></li><li><span class="zNice-select-item">Thailand</span></li><li><span class="zNice-select-item">Togo</span></li><li><span class="zNice-select-item">Tokelau</span></li><li><span class="zNice-select-item">Tonga</span></li><li><span class="zNice-select-item">Trinidad &amp; Tobago</span></li><li><span class="zNice-select-item">Tunisia</span></li><li><span class="zNice-select-item">Turkey</span></li><li><span class="zNice-select-item">Turkmenistan</span></li><li><span class="zNice-select-item">Turks &amp; Caicos Is</span></li><li><span class="zNice-select-item">Tuvalu</span></li><li><span class="zNice-select-item">Uganda</span></li><li><span class="zNice-select-item">Ukraine</span></li><li><span class="zNice-select-item">United Arab Emirates</span></li><li><span class="zNice-select-item">United Kingdom</span></li><li><span class="zNice-select-item">United States of America</span></li><li><span class="zNice-select-item">Uruguay</span></li><li><span class="zNice-select-item">Uzbekistan</span></li><li><span class="zNice-select-item">Vanuatu</span></li><li><span class="zNice-select-item">Vatican City State</span></li><li><span class="zNice-select-item">Venezuela</span></li><li><span class="zNice-select-item">Vietnam</span></li><li><span class="zNice-select-item">Virgin Islands (Brit)</span></li><li><span class="zNice-select-item">Virgin Islands (USA)</span></li><li><span class="zNice-select-item">Wake Island</span></li><li><span class="zNice-select-item">Wallis &amp; Futana Is</span></li><li><span class="zNice-select-item">Yemen</span></li><li><span class="zNice-select-item">Zaire</span></li><li><span class="zNice-select-item">Zambia</span></li><li><span class="zNice-select-item">Zimbabwe</span></li></ul></span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-full-col">
                                <span class="zNice-wrap zNice-tArea"><span class="zNice-bg"></span><textarea name="subject" id="subject" placeholder="Tell us what are you intersted in"></textarea></span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-col">
                                <div class="radio-box">
                                    <div class="radio-box-left">
                                        <span>Contact me by:</span>
                                    </div>
                                    <div class="radio-box-right">
                                        <div class="radio-box-item">
                                            <label>
                                                <span class="zNice-wrap zNice-radio"><span class="zNice-bg"></span><input type="radio" name="contact_type" id="contact_type_telephone" value="telephone"></span>
                                                <span>Telephone</span>
                                            </label>
                                        </div>
                                        <div class="radio-box-item">
                                            <label>
                                                <span class="zNice-wrap zNice-radio zNice-checked"><span class="zNice-bg"></span><input type="radio" name="contact_type" id="contact_type_email" value="email" checked="checked"></span>
                                                <span>Email</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-col">
                                <span class="button btn btn-danger btn-lm"><input type="submit" class="" value=""><span class="ileft">Contact us</span><span class="iright"></span></span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="clear"></div>
            <div class="jumbotron-socs">
                <ul>
                    <li>
                        <a target="_blank" href="https://twitter.com/AtoZForex"><i class="icon-sprite icon-twitter-w"></i></a>
                    </li>
                    <li>
                        <span>Follow us on Twitter to get instant<br>updates on the market moves;</span>
                    </li>
                    <li>
                        <a target="_blank" href="https://www.linkedin.com/company/atoz-forex"><i class="icon-sprite icon-instagram-w"></i></a>
                    </li>
                    <li>
                        <a target="_blank" href="https://plus.google.com/+Atozforex/posts"><i class="icon-sprite icon-google-w"></i></a>
                    </li>
                    <li>
                        <a target="_blank" href="https://www.facebook.com/atozmarkets"><i class="icon-sprite icon-facebook-w"></i></a>
                    </li>
                    <li>
                        <span>connect with us on Google Plus, Facebook and<br>LinkedIn to be up-to-date with everything from A to Z.</span>
                    </li>
                </ul>
            </div>
            <a href="#" class="go-down"><i class="icon-sprite icon-circle-arrow-down-w"></i></a>
        </div>
    </div>
    <div class="container">


        <div class="contacts-list">
            <div class="contacts-list__item">
                <a href="mailto:info@atozforex.com">
                    <div class="contacts-list__img">
                        <span style="background-image: url('http://atozforex.com/verstka/images/contacts-img1.png');"></span>
                    </div>
                    <div class="contacts-list__text">
                        For general enquiries and feedback, email us at: <b>info@atozforex.com</b>
                    </div>
                </a>
            </div>
            <div class="contacts-list__item">
                <a href="mailto:careers@AtoZforex.com">
                    <div class="contacts-list__img">
                        <span style="background-image: url('http://atozforex.com/verstka/images/contacts-img2.png');"></span>
                    </div>
                    <div class="contacts-list__text">
                        For career opportunities send us an email to <b>careers@AtoZforex.com</b>
                    </div>
                </a>
            </div>
            <div class="contacts-list__item">
                <a href="mailto:media@atozforex.com">
                    <div class="contacts-list__img">
                        <span style="background-image: url('http://atozforex.com/verstka/images/contacts-img3.png');"></span>
                    </div>
                    <div class="contacts-list__text">
                        For contributor analyses, news and press releases, email us at <b>media@atozforex.com</b>
                    </div>
                </a>
            </div>
            <div class="contacts-list__item">
                <a href="/about/advertise-us/">
                    <div class="contacts-list__img">
                        <span style="background-image: url('http://atozforex.com/verstka/images/contacts-img4.png');"></span>
                    </div>
                    <div class="contacts-list__text">
                        For advertising opportunities see our 'Advertise' page                    </div>
                </a>
            </div>
        </div>
    </div>
</div>

</div>
<?php get_footer(); ?>