<?php /* Template Name: Forex Courses */ ?>


<?php get_header(); ?>
<div class="container">
</div>
<?php get_footer(); ?>

