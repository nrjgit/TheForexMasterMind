<?php /* Template Name: Retail FX */ ?>

<?php get_header(); ?>
<div class="container"></div>
<?php get_footer(); ?>