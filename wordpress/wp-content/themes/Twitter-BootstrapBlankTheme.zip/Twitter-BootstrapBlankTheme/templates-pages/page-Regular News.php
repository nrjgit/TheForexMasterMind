<?php /* Template Name: Regular News */ ?>

<?php get_header(); ?>
<div class="container"></div>
<?php get_footer(); ?>