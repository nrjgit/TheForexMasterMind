<?php /* Template Name: Binary Signals */ ?>


<?php get_header(); ?>
<div class="container">
</div>
<?php get_footer(); ?>

